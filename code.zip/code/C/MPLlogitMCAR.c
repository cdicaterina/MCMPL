//
//  MPLunb_logitMD.c
//  

#include <R.h>
#include <Rmath.h>
#include <R_ext/Applic.h>
#include <R_ext/Lapack.h>

// auxiliar functions
#define MAT2(mat, i, j, nI) (mat[i+j*nI])

double eps=2.22e-15;

static double prange(double p)
{
    double mu;
    mu=p;
    
    if (mu<eps)
        mu=eps;
    if (mu>(1-eps))
        mu=(1-eps);
    return(mu);
}

static double lik_i_dlogit(double lambda,
                           double *beta,
                           int dimBeta,
                           double *X,
                           int dimData,
                           double *y)
{   double eta, mu, l;
    int i,j;
    
    l=0.0;
    for(i=0; i<dimData; i++)
    {
        eta= lambda;
        for(j=0; j< dimBeta; j++)
            eta += MAT2(X,i,j,dimData) * beta[j];
        mu= plogis(eta,0,1,1,0);
        mu= prange(mu);
        l += y[i] * log(mu) + (1.0 - y[i]) * log(1-mu);
    }
    return(l);
}


static double gr_i_dlogit( double lambda,
                          double *beta,
                          int dimBeta,
                          double *X,
                          int dimData,
                          double *y)
{   double eta, mu, grad;
    int i,j;
    
    
    grad=0.0;
    
    for(i=0; i< dimData; i++)
    {
        eta=lambda;
        for(j=0; j< dimBeta; j++)
            eta += MAT2(X,i,j,dimData) * beta[j];
        mu= plogis(eta,0,1,1,0);
        mu= prange(mu);
        grad += (y[i] - mu);
    }
    return(grad);
}


static double hess_i_dlogit( double lambda,
                            double *beta,
                            int dimBeta,
                            double *X,
                            int dimData,
                            double *y)
{   double eta, mu, hess;
    int i,j;
    
    hess=0.0;
    
    for(i=0; i< dimData; i++)
    {
        eta=lambda;
        for(j=0; j< dimBeta; j++)
            eta += MAT2(X,i,j,dimData) * beta[j];
        mu= plogis(eta,0,1,1,0);
        mu= prange(mu);
        hess += mu * (1.0 - mu);
    }
    return(hess);
}


static double FS_i_dlogit(double lambdain,
                          double *beta,
                          int dimBeta,
                          double *X,
                          int dimData,
                          double *y,
                          double mytol,
                          int maxiter)
{  int i, iter;
    double lambdaold,lambdanew,s1,s2,f0,f1,lam,g0,g1,Delta,diff,H;
    
    
    lambdaold = lambdain;
    g0 = gr_i_dlogit(lambdaold,beta,dimBeta,X,dimData,y);
    f0 = R_pow_di(g0,2) * 0.5;
    iter = 0;
    
    while(iter< maxiter)
    { iter += 1;
        H = 1 / hess_i_dlogit(lambdaold,beta,dimBeta,X,dimData,y);
        g1 = gr_i_dlogit(lambdaold,beta,dimBeta,X,dimData,y);
        Delta = H * g1;
        lambdanew= lambdaold + Delta;
        f1= R_pow_di(g1,2) * 0.5;
        // backtracking loop
        i=0;
        lam = -2.0 * f0;
        while(f1>(f0+0.0001*lam))
        {
            //Rprintf("backtracking: %i, \n",i);
            i +=1;
            Delta = Delta * 0.5;
            lambdanew= lambdaold + Delta;
            lam = lam * 0.5;
            g1 = gr_i_dlogit(lambdanew,beta,dimBeta,X,dimData,y);
            f1= R_pow_di(g1,2) * 0.5;
            if (i>100)
            {Rprintf("backtracking failed:  \n");
                break;}
        }
        diff = lambdaold - lambdanew;
        s1 = fabs(g1);
        if (s1< mytol)
            break;
        s1 = fabs(diff);
        s2 = fabs(lambdanew);
        if ( (s1/(1+s2))< mytol)
            break;
        lambdaold = lambdanew;
        g0=g1;
        f0=f1;
    }
    return(lambdanew);
}


void dyn_logit_alpha(double *ain,
                     double *beta,
                     double *Xe,
                     int *dimBeta,
                     double *y,
                     int *dimData,
                     int *nG,
                     int *dimG,
                     int *maxnG,
                     double *mytol,
                     int *maxiter,
                     double *a)
{
    
    double *yi=(double *) R_alloc(*maxnG, sizeof(double));
    double *Xei=(double *) R_alloc(*maxnG * *dimBeta, sizeof(double));
    int i,j,ind,k,n,h;
    
    
    ind= 0;
    for(i=0; i< *dimG; i++)
    { n = nG[i];
        for(j=0; j<n; j++)
        { k = j + ind;
            yi[j] = y[k];
            for(h=0; h<*dimBeta; h++)
                MAT2(Xei,j,h,n) = MAT2(Xe,k,h,*dimData);
        }
        
        
        a[i] = FS_i_dlogit(ain[i],beta,*dimBeta,Xei,n,yi,*mytol,*maxiter);
        ind += nG[i];
    }
}

/* An  attempt to obtain   M via MC simulation */
static double unb_lik_M_i_logitMD_simu(double *beta,
                                   int dimBeta,
                                   double *X,
                                   double *Xg,
                                   int dimData,
                                   int mi,
                                   double *y,
                                   int R,
                                   double *betasim,
                                   double alphasim,
                                   double *psim)
{   double l,alpha_s,info,score,scoresim,etasim,eta,mu,musim,I;
    int i,j,k;
    double p;
    double *ys=(double *)  R_alloc(mi, sizeof(double));
    double *Ms=(double *)  R_alloc(mi, sizeof(double));
    
    
    GetRNGstate();
    
    alpha_s = FS_i_dlogit(0.0,beta,dimBeta,X,dimData,y,0.000001,100);
    l = lik_i_dlogit(alpha_s,beta,dimBeta,X,dimData,y);
    info =  hess_i_dlogit(alpha_s,beta,dimBeta,X,dimData,y);
    l += 0.5 * log(info);
    
    /* now the I factor   */
    I = 0.0;
    for(j=0; j<R; j++)
    {
        score = 0.0;
        scoresim = 0.0;
        for(i=0; i<mi; i++)
        {
            p = psim[i];
            eta = alpha_s;
            etasim = alphasim;
            for(k=0; k<dimBeta; k++)
            {
                eta += MAT2(Xg,i,k,mi) * beta[k];
                etasim += MAT2(Xg,i,k,mi) * betasim[k];
            }
            mu = plogis(eta,0,1,1,0);
            mu = prange(mu);
            musim = plogis(etasim,0,1,1,0);
            musim = prange(musim);
            ys[i] = rbinom(1.0,musim);
            Ms[i] = rbinom(1.0,p);
            score += (ys[i]-mu) * (1-Ms[i]);
            scoresim +=  (ys[i]-musim) * (1-Ms[i]);
        }
        I += score * scoresim / R;
    }
    if(I>0)
        l +=  - log( I );
    
    PutRNGstate();
    return(l);
}


// p.hat vector sum(m_i)*1
void unb_logitMD_MPL_simu4(double *beta,
                           int *dimBeta,
                           double *X,
                           double *Xg,
                           int *dimData,
                           int *m,         
                           int *summ,
                           int *maxm,
                           double *y,
                           int *nG,
                           int *dimG,
                           int *maxnG,
                           int *R,
                           double *betaMle,
                           double *alphaMle,
                           double *phat,
                           double *l)
{
    
    double *yi=(double *) R_alloc(*maxnG, sizeof(double));
    double *pi=(double *) R_alloc(*maxm, sizeof(double));
    double *Xi=(double *) R_alloc(*maxnG * *dimBeta, sizeof(double));
    double *Xgi=(double *) R_alloc(*maxm * *dimBeta, sizeof(double));
    int i,j,ind,id,k,n,h,r,s,mi;
    double alphai;
    
    *l=0.0;
    ind=0;
    id=0;
    for(i=0; i< *dimG; i++)
    {
        mi = m[i];
        n = nG[i];
        alphai = alphaMle[i];
        
        for(r=0; r<n; r++)
        {
            k = r + ind;
            yi[r] = y[k];
            for(h=0; h< *dimBeta; h++)
                MAT2(Xi,r,h,n) = MAT2(X,k,h,*dimData);
        }
        for(j=0; j<mi; j++)
        {
            s = j + id;
            pi[j] = phat[s];
            for(h=0; h< *dimBeta; h++)
                MAT2(Xgi,j,h,mi) = MAT2(Xg,s,h,*summ);
        }
        *l += unb_lik_M_i_logitMD_simu(beta,*dimBeta,Xi,Xgi,n,mi,yi,*R,betaMle,alphai,pi);
        ind += nG[i];
        id += m[i];
    }
    
}



