#include <R.h>

#define MAT3(mat,i,t,r,nI,nT) (mat[i + t * nI + r * nI * nT])

void Imumu(double *rho,
		 double *rhohat,
		 double *muhat,
		 double *muhat_rho,
		 double *ystar,
		 int *dimN,
		 int *dimT,
		 int *dimR,
		 double *output)
{
	int i, t, r;
  	double sum, ell1, ell2;
 
  	for(i=0; i< *dimN; i++){
	 	sum=0.0;
      	for(r=0; r< *dimR; r++){
      		ell1=0.0;
      		ell2=0.0;
      		for(t=1; t< ((*dimT)+1); t++){
        			ell1+=MAT3(ystar,i,t,r,*dimN,((*dimT)+1)) - muhat[i] - (*rhohat) * MAT3(ystar,i,(t-1),r,*dimN,((*dimT)+1));
        			ell2+=MAT3(ystar,i,t,r,*dimN,((*dimT)+1)) - muhat_rho[i] - (*rho) * MAT3(ystar,i,(t-1),r,*dimN,((*dimT)+1));
	  		}
	  		sum+=ell1 * ell2;    	  
  	  	} 
  		output[i]=sum/(*dimR);  
  	}
}
