//
//  MPLsurv.c
//  


#include <R.h>
#include <Rmath.h>
#include <R_ext/Applic.h>
#include <stdlib.h>
#include <stdio.h>

// auxiliar functions
#define MAT2(mat, i, j, nI) (mat[i+j*nI])


static double l_lambdai(int Ti,
                        double xi,
                        double *beta,
                        int dimBeta,
                        double lambdai,
                        double *yi,
                        int *deltai,
                        double *Xi)
{
    int i,j;
    double di=0.0, s2i=0.0, grad=0.0, eta=0.0;
    
    for(i=0; i<Ti; i++)
    {
        di += deltai[i];
        eta=lambdai;
        for(j=0; j<dimBeta; j++)
            eta += MAT2(Xi,i,j,Ti) * beta[j];
        s2i += R_pow(yi[i], xi) * exp(-xi*eta);
    }
    grad = -di*xi + xi*s2i;
    return(grad);
}


void l_lambdaiR(int *Ti,
                double *xi,
                double *beta,
                int *dimBeta,
                double *lambdai,
                double *yi,
                int *deltai,
                double *Xi,
                double *grad)
{
    int i,j;
    double di=0.0, s2i=0.0, eta=0.0;
    
    *grad=0.0;
    
    for(i=0; i< *Ti; i++)
    {
        di += deltai[i];
        eta = *lambdai;
        for(j=0; j< *dimBeta; j++)
            eta += MAT2(Xi,i,j,*Ti) * beta[j];
        s2i += R_pow(yi[i], *xi) * exp(-*xi * eta);
    }
    
    *grad = -di * *xi + *xi * s2i;
}


//  ith second derivative
static double hess_i(int Ti,
                     double xi,
                     double *beta,
                     int dimBeta,
                     double lambdai,
                     double *yi,
                     double *Xi)
{
    int i,j;
    double s2i=0.0, hess=0.0, p1=0.0, eta=0.0;
    
    for(i=0; i<Ti; i++)
    {
        eta=lambdai;
        for(j=0; j<dimBeta; j++)
            eta += MAT2(Xi,i,j,Ti) * beta[j];
        s2i += R_pow(yi[i], xi) * exp(-xi * eta);
    }
    p1 = R_pow_di(xi, 2);
    hess = -p1 * s2i;
    
    return(hess);
}


// Constrained estimate of lambda, given psi - Nx1 vector
void lambda_psi(int *n,
                int *N,
                int *T,
                int *maxT,
                double *xi,
                double *beta,
                int *dimBeta,
                double *y,
                double *X,
                int *delta,
                double *lambda)
{
    double *yi=(double *) R_alloc(*maxT, sizeof(double));
    double *Xi=(double *) R_alloc(*maxT * *dimBeta, sizeof(double));
    int *deltai=(int *) R_alloc(*maxT, sizeof(int));
    
    int i, j, ind, k=0, t=0, h, di;
    double s2i, eta;
    
    ind=0;
    for(i=0; i< *N; i++)
    {
        t=T[i];
        s2i=0.0;
        di=0;
        for(j=0; j<t; j++)
        {
            eta=0.0;
            k = j + ind;
            yi[j] = y[k];
            deltai[j] = delta[k];
            di += deltai[j];
            for(h=0; h< *dimBeta; h++) {
                MAT2(Xi,j,h,t) = MAT2(X,k,h,*n);
                eta += MAT2(Xi,j,h,t) * beta[h];
            }
            s2i += R_pow(yi[j], *xi) * exp(- *xi * eta);
        };
        lambda[i] = -(1/ *xi) * log(di/s2i);
        ind += T[i];
    }
}


// Constrained estimate of lambda_i, given psi
static double lambdai_psi(int Ti,
                          double xi,
                          double *beta,
                          int dimBeta,
                          double *yi,
                          double *Xi,
                          int *deltai)
{
    int i, j;
    double di=0.0, s2i=0.0, eta, lambdaipsi=0.0;
    
    for(i=0; i< Ti; i++)
    {
        eta=0.0;
        di += deltai[i];
        for(j=0; j<dimBeta; j++)
            eta += MAT2(Xi,i,j,Ti) * beta[j];
        s2i += R_pow(yi[i], xi) * exp(- xi * eta);
    }
    lambdaipsi = -(1/ xi) * log(di/s2i);
    return(lambdaipsi);
}


// profile loglik ith cluster
static double pllik_i(int Ti,
                      double xi,
                      double *beta,
                      int dimBeta,
                      double *yi,
                      int *deltai,
                      double *Xi)
{
    int i, j;
    double pll, di=0.0, s1i=0.0, s2i=0.0, s3i=0.0, eta;
    
    pll=0.0;
    
    for(i=0; i<Ti; i++)
    {
        eta=0.0;
        di += deltai[i];
        for(j=0; j<dimBeta; j++)
            eta += MAT2(Xi,i,j,Ti) * beta[j];
        s1i += deltai[i] * eta;
        s2i += R_pow(yi[i], xi) * exp(-xi * eta);
        s3i += deltai[i] * log(yi[i]);
    }
    pll = ((log(xi)-1) * di) + ((xi-1) * s3i) + (di * log(di)) - (di * log(s2i)) - xi * s1i;
    
    return(pll);
}


//modified prof. log likelihood for randomly right-censored data
static double MPLsurv_i(int Ti,
                        double xi,
                        double *beta,
                        int dimBeta,
                        double *yi,
                        int *deltai,
                        double *Xi,
                        double *ystari,         
                        int *deltastari,
                        int R,
                        double xihat,
                        double *betahat,
                        double lambdahati)
{
    double *ystar=(double *) R_alloc(Ti, sizeof(double));
    int *deltastar=(int *) R_alloc(Ti, sizeof(int));
    int i, j;
    double li=0.0, lambdaipsi=0.0, info=1.0, score, scoresim, I;
    
    GetRNGstate();
    
    lambdaipsi = lambdai_psi(Ti,xi,beta,dimBeta,yi,Xi,deltai);
    li = pllik_i(Ti,xi,beta,dimBeta,yi,deltai,Xi);
    info = hess_i(Ti,xi,beta,dimBeta,lambdaipsi,yi,Xi);
    li += 0.5 * log( -info );
    
    /* now the I factor */
    I = 0.0;
    for(j=0; j<R; j++)
    {
        score=0.0;
        scoresim=0.0;
        for(i=0; i<Ti; i++)
        {
            ystar[i] = MAT2(ystari,i,j,Ti);
            deltastar[i] = MAT2(deltastari,i,j,Ti);
        }
        score = l_lambdai(Ti,xi,beta,dimBeta,lambdaipsi,ystar,deltastar,Xi);
        scoresim = l_lambdai(Ti,xihat,betahat,dimBeta,lambdahati,ystar,deltastar,Xi);
        I += score * scoresim / R;
     }
    if(I>0)
        li += - log( I );
    
    PutRNGstate();
    return(li);
}

// input vectors: nx1, X matrix: nxp
void MPLsurvC(double *xi,
              double *beta,
              int *dimBeta,
              double *X,
              int *N,
              int *T,
              int *n,
              int *maxT,
              double *y,
              int *delta,
              double *ystar,
              int *deltastar,
              int *R,
              double *xihat,
              double *betahat,
              double *lambdahat,
              double *l)
{
    double *yi=(double *) R_alloc(*maxT, sizeof(double));
    double *Xi=(double *) R_alloc(*maxT * *dimBeta, sizeof(double));
    int *deltai=(int *) R_alloc(*maxT, sizeof(int));
    double *ystari=(double *) R_alloc(*maxT * *R, sizeof(double));
    int *deltastari=(int *) R_alloc(*maxT * *R, sizeof(int));

    int i, j, ind, k=0, h, Ti=0, r;
    double lambdahati;
    
    ind=0;
    *l=0.0;
    
    for(i=0; i< *N; i++)
    {
        Ti = T[i];
        lambdahati = lambdahat[i];
        for(j=0; j< Ti; j++)
        {
            k = j + ind;
            yi[j] = y[k];
            deltai[j] = delta[k];
            for(r=0; r< *R; r++) {
                MAT2(ystari,j,r,Ti) = MAT2(ystar,k,r,*n);
                MAT2(deltastari,j,r,Ti) = MAT2(deltastar,k,r,*n);
            }
            for(h=0; h< *dimBeta; h++)
                MAT2(Xi,j,h,Ti) = MAT2(X,k,h,*n);
        }
        *l += MPLsurv_i(Ti,*xi,beta,*dimBeta,yi,deltai,Xi,ystari,deltastari,*R,*xihat,betahat,lambdahati);
        ind += T[i];
    }
}
