//
//  NImisMPL.c
//  


#include <R.h>
#include <Rmath.h>
#include <R_ext/Applic.h>
#include <R_ext/Lapack.h>

// auxiliar functions
#define MAT2(mat, i, j, nI) (mat[i+j*nI])

double eps=2.22e-15;

static double prange(double p)
{
    double mu;
    mu=p;
    
    if (mu<eps)
        mu=eps;
    if (mu>(1-eps))
        mu=(1-eps);
    return(mu);
}

//observed log-lik_i
static double lik_i_NIlogit(double lambda,
                            double *beta,
                            int dimBeta,
                            double *gamma,
                            int dimGamma,
                            double *X,
                            int dimData, 
                            double *y,
                            int *M)
{   double eta, omega, mu, l;
    int i,j,k;

    l=0.0;
    for(i=0; i<dimData; i++)
    {
        eta= lambda;
        omega=gamma[0];

        for(j=0; j< dimBeta; j++)
            eta += MAT2(X,i,j,dimData) * beta[j];
        for(k=0; k< (dimGamma-2); k++)
            omega += MAT2(X,i,k,dimData) * gamma[k+1];

        mu= plogis(eta,0,1,1,0);
        mu= prange(mu);

        l += (1-M[i]) * (y[i] * log(mu) + (1.0 - y[i]) * log(1.0-mu) +
             log(1.0-prange(plogis(omega+gamma[dimGamma-1]*y[i],0,1,1,0)))) +
             M[i] * log((1.0-mu)*prange(plogis(omega,0,1,1,0))+
             mu * prange(plogis(omega+gamma[dimGamma-1],0,1,1,0)));
    }
    return(l);
}

void NI_logit_PL(double *alpha,
                 double *beta,
                 int *dimBeta,
                 double *gamma,
                 int *dimGamma,
                 double *X,
                 int *dimData,
                 double *y,
                 int *M,
                 int *m,
                 int *summ,
                 int *maxm,
                 double *l)
{

    double *yi=(double *) R_alloc(*maxm, sizeof(double));
    int *Mi=(int *) R_alloc(*maxm, sizeof(int));
    double *Xi=(double *) R_alloc(*maxm * *dimBeta, sizeof(double));
    double alphai;
    int i,j,ind,k,n,h;

    *l=0.0;
    ind= 0;
    for(i=0; i< *dimData; i++)
    {
        n = m[i];
        alphai = alpha[i];
        for(j=0; j<n; j++)
        {
            k = j + ind;
            yi[j] = y[k];
            Mi[j] = M[k];
            for(h=0; h<*dimBeta; h++)
                MAT2(Xi,j,h,n) = MAT2(X,k,h,*summ);
        }
        *l += lik_i_NIlogit(alphai,beta,*dimBeta,gamma,*dimGamma,Xi,n,yi,Mi);
        ind += m[i];
    }
}

                 
//stratum score wrt alpha_i: l_(alpha_i) obs
static double gr_i_NIlogit(double lambda,
                           double *beta,
                           int dimBeta,
                           double *gamma,
                           int dimGamma,
                           double *X,
                           int dimData,
                           double *y,
                           int *M)
{
    double eta, omega, mu, grad;
    int i,j,k;
    
    
    grad=0.0;
    
    for(i=0; i< dimData; i++)
    {
        eta=lambda;
        omega=gamma[0];
        
        for(j=0; j< dimBeta; j++)
            eta += MAT2(X,i,j,dimData) * beta[j];
        for(k=0; k< (dimGamma-2); k++)
            omega += MAT2(X,i,k,dimData) * gamma[k+1];
        
        mu= plogis(eta,0,1,1,0);
        mu= prange(mu);
        grad += (1-M[i]) * (y[i] - mu) + M[i] * mu *
                ((exp(gamma[dimGamma-1]))-1.0)/((exp(eta+gamma[dimGamma-1])*
                (1+(exp(omega))) + 1.0 + exp(omega+gamma[dimGamma-1])));
    }
    return(grad);
}

//stratum hessian: j_(alpha_i,alpha_i) obs
static double hess_i_NIlogit(double lambda,
                             double *beta,
                             int dimBeta,
                             double *gamma,
                             int dimGamma,
                             double *X,
                             int dimData,
                             double *y,
                             int *M)
{   double eta, omega, mu, hess;
    int i,j,k;
    
    hess=0.0;
    
    for(i=0; i< dimData; i++)
    {
        eta=lambda;
        omega=gamma[0];
        
        for(j=0; j< dimBeta; j++)
            eta += MAT2(X,i,j,dimData) * beta[j];
        for(k=0; k< (dimGamma-2); k++)
            omega += MAT2(X,i,k,dimData) * gamma[k+1];
        
        mu= plogis(eta,0,1,1,0);
        mu= prange(mu);
        hess += (1-M[i]) * mu * (1.0 - mu) + M[i] * mu *
                (1.0-exp(gamma[dimGamma-1])) * ((1.0-mu) *
                (1.0+(exp(omega+gamma[dimGamma-1]))) - mu *
                ((exp(eta+gamma[dimGamma-1])) *
                (1.0+(exp(omega)))))/((((exp(eta+gamma[dimGamma-1])) *
                (1.0+(exp(omega))) + 1.0 + (exp(omega+gamma[dimGamma-1])))) *
                (((exp(eta+gamma[dimGamma-1])) *
                (1.0+(exp(omega))) + 1.0 + (exp(omega+gamma[dimGamma-1])))));
    }
    return(hess);
}

//Fisher-Scoring
static double FS_i_NIlogit(double lambdain,
                           double *beta,
                           int dimBeta,
                           double *gamma,
                           int dimGamma,
                           double *X,
                           int dimData,
                           double *y,
                           int *M,
                           double mytol,
                           int maxiter)
{   int i,iter;
    double lambdaold,lambdanew,s1,s2,f0,f1,lam,g0,g1,Delta,diff,H;
    
    lambdaold = lambdain;
    g0= gr_i_NIlogit(lambdaold,beta,dimBeta,gamma,dimGamma,X,dimData,y,M);
    f0 = R_pow_di(g0,2) * 0.5;
    iter = 0;
    
    while(iter< maxiter)
    { iter += 1;
        H = 1 / hess_i_NIlogit(lambdaold,beta,dimBeta,gamma,dimGamma,X,dimData,y,M);
        g1 = gr_i_NIlogit(lambdaold,beta,dimBeta,gamma,dimGamma,X,dimData,y,M);
        Delta = H * g1;
        lambdanew= lambdaold + Delta;
        f1= R_pow_di(g1,2) * 0.5;
        // backtracking loop
        i=0;
        lam = -2.0 * f0;
        while(f1>(f0+0.0001*lam))
        {
            //Rprintf("backtracking: %i, \n",i);
            i +=1;
            Delta = Delta * 0.5;
            lambdanew= lambdaold + Delta;
            lam = lam * 0.5;
            g1 = gr_i_NIlogit(lambdanew,beta,dimBeta,gamma,dimGamma,X,dimData,y,M);
            f1= R_pow_di(g1,2) * 0.5;
            if (i>100)
            {Rprintf("backtracking failed:  \n");
                break;}
        }
        diff = lambdaold - lambdanew;
        s1 = fabs(g1);
        if (s1< mytol)
            break;
        s1 = fabs(diff);
        s2 = fabs(lambdanew);
        if ( (s1/(1+s2))< mytol)
            break;
        lambdaold = lambdanew;
        g0=g1;
        f0=f1;
    }
    return(lambdanew);
}


//constrained alpha_i's estimates
void NI_logit_alpha(double *ain,
                    double *beta,
                    double *Xe,
                    int *dimBeta,
                    double *gamma,
                    int *dimGamma,
                    double *y,
                    int *M,
                    int *dimData,
                    int *nG,
                    int *dimG,
                    int *maxnG,
                    double *mytol,
                    int *maxiter,
                    double *a)
{ 
    
    double *yi=(double *) R_alloc(*maxnG, sizeof(double));
    int *Mi=(int *) R_alloc(*maxnG, sizeof(int));
    double *Xei=(double *) R_alloc(*maxnG * *dimBeta, sizeof(double));
    int i,j,ind,k,n,h;
    
    
    ind= 0;
    for(i=0; i< *dimG; i++)
    {
        n = nG[i];
        
        for(j=0; j<n; j++)
        {
          k = j + ind;
          yi[j] = y[k];
          Mi[j] = M[k];
          for(h=0; h<*dimBeta; h++)
              MAT2(Xei,j,h,n) = MAT2(Xe,k,h,*dimData);
        }
        
        a[i]=FS_i_NIlogit(ain[i],beta,*dimBeta,gamma,*dimGamma,Xei,n,yi,Mi,*mytol,*maxiter);
        ind += nG[i];
    }
}


/* An  attempt to obtain MPL via MC simulation */
static double unb_lik_M_i_logitNI_simu(double *beta,
                                       int dimBeta,
                                       double *X,
                                       double *gamma,
                                       int dimGamma,
                                       int mi,
                                       double *y,
                                       int *M,
                                       int R,
                                       double *betasim,
                                       double alphasim,
                                       double *gammasim)
{
    double l,alpha_s,info,score,scoresim,etasim,musim,I,omegasim;
    int h,i,j,k,r;
    double psim;
    double *ys=(double *)  R_alloc(mi, sizeof(double));
    int *Ms=(int *)  R_alloc(mi, sizeof(int));
    
    GetRNGstate();
    
    alpha_s = FS_i_NIlogit(0.0,beta,dimBeta,gamma,dimGamma,X,mi,y,M,0.000001,100);
    l = lik_i_NIlogit(alpha_s,beta,dimBeta,gamma,dimGamma,X,mi,y,M);
    info =  hess_i_NIlogit(alpha_s,beta,dimBeta,gamma,dimGamma,X,mi,y,M);
    l += 0.5 * log(info);

    I = 0.0;
    for(j=0; j<R; j++)
    {
        
        score = 0.0;
        scoresim = 0.0;
        for(r=0; r<mi; r++)
        {
            ys[r] = 0.0;
            Ms[r] = 0;
        }
        
        for(i=0; i<mi; i++)
        {
            etasim = alphasim;
            omegasim = gammasim[0];
            
            for(k=0; k<dimBeta; k++)
            {
                etasim += MAT2(X,i,k,mi) * betasim[k];
            }
            for(h=0; h<(dimGamma-2); h++)
            {
                omegasim += MAT2(X,i,h,mi) * gammasim[h+1];
            }
            
            musim = plogis(etasim,0,1,1,0);
            musim = prange(musim);
            ys[i] = rbinom(1.0,musim);
            
            psim = plogis((omegasim+((gammasim[dimGamma-1]) * ys[i])),0,1,1,0);
            psim = prange(psim);
            Ms[i] = rbinom(1.0,psim);
        }
        
        score = gr_i_NIlogit(alpha_s,beta,dimBeta,gamma,dimGamma,X,mi,ys,Ms);
        scoresim = gr_i_NIlogit(alphasim,betasim,dimBeta,gammasim,dimGamma,X,mi,ys,Ms);
        
        I += score * scoresim / R;
    }
    if(I>0)
        l +=  - log( I );
    
    PutRNGstate();
    return(l);
}


// MPL with simulation -> input: gammahat
void unb_logitNI_MPL_simu(double *beta,
                          int *dimBeta,
                          double *gamma,
                          int *dimGamma,
                          double *X,
                          int *dimData,
                          int *m,
                          int *summ,
                          int *maxm,
                          double *y,
                          int *M,
                          int *R,
                          double *betaMle,
                          double *alphaMle,
                          double *gammaMle,
                          double *l)
{
    double *yi=(double *) R_alloc(*maxm, sizeof(double));
    double *Xi=(double *) R_alloc(*maxm * *dimBeta, sizeof(double));
    int *Mi=(int *) R_alloc(*maxm, sizeof(int));
    int i,j,id,k,h,mi;
    double alphai;
    
    *l=0.0;
    id=0;
    for(i=0; i< *dimData; i++)
    {
        mi = m[i];
        alphai = alphaMle[i];
        
        for(j=0; j<mi; j++)
        {
            k = j + id;
            yi[j] = y[k];
            Mi[j] = M[k];
            for(h=0; h< *dimBeta; h++)
                MAT2(Xi,j,h,mi) = MAT2(X,k,h,*summ);
        }
        *l += unb_lik_M_i_logitNI_simu(beta,*dimBeta,Xi,gamma,*dimGamma,mi,yi,Mi,*R,betaMle,alphai,gammaMle);
        id += m[i];
    }
    
}

