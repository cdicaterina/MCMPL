This folder contains the code written to perform the simulation studies, data applications and figures in Di Caterina, Cortese, Sartori (2018), “Monte Carlo modified profile likelihood for clustered data”. Specifically, folder “C” includes the C code, while folder “R” contains the R code.

The R code uses dynamic libraries for efficient computation. The dynamic libraries are produced on the command line of your terminal window with the command
R CMD SHLIB filename.c
 
where filename.c stands for the c files in folder "C".

This action has been successfully tested on a MAC OS X operating system (version 10.13.5).
For details about compilers required for producing the dynamic libraries we refer to the R manual “Writing R Extensions” available at URL http://cran.r- project.org/doc/manuals/R-exts.html.

Folder “R” includes the files
- ar1simu.R: R script to run simulation studies in Section S2 of the Supplementary material;
- dataHIV.csv: dataset from the HIV clinical trial of Section 5.5;
- figureAR1.R: R script to produce Figure S1 in the Supplementary material;
- HIVdata.R: R script to analyse data from the HIV clinical trial of Section 5.5 and produce Figure 1;
- missingLogit_simu.R: R script to run simulation studies in Section 4.3 and in Section S3 of the Supplementary material;
- missingProbit_simu.R: R script to run simulation studies in Section S3 of the Supplementary material;
- toenail.R: R script to analyse data from the toenail infection study of Section 4.4;
- toenail.Rdata: dataset from the toenail infection study of Section 4.4;
- Weib_simu.R: R script to run simulation studies in Section 5.4. 

Please note that in the R scripts for simulations only one combination (T, N) is considered for the sake of succinctness. Yet all results are reproducible by changing those values accordingly.