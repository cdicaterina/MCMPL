###### SIMULATIONS #######
### Probit link function

library(gee)
## download the package panelMPL from https://ruggerobellio.weebly.com/software.html
library(panelMPL)

dyn.load("MPLprobitMCAR.so")
dyn.load("MPLprobitMNAR.so")

### DATA SIMULATION in VECTOR form - no intercept in gamma vector
### MCAR
## Random effects
simuMCAR.probit <- function(X, panel, beta, alpha = NULL, gamma = c(0, 1), 
                            Nsim = 1, seed = 123) {
  if (is.null(seed)) seed = .Random.seed
  set.seed(seed)
  
  n <- nrow(X)                #sum(m_i)
  q <- length(unique(panel))  #N
  m <- tapply(rep(1, nrow(X)), panel, sum)   #m_i
  
  y <- M <- out <- matrix(0, ncol = Nsim, nrow = n)
  
  for (i in 1:Nsim){
    alpha <- rnorm(q, mean = -0.35, sd = 1)
    alpha.v <- as.vector(alpha)/1.6  ## prima mancava "/1.6" (07/05/2018)
    if(length(beta) != ncol(X)) stop("Wrong length of beta!")
    if(length(gamma) != length(beta) + 1) stop("Wrong length of gamma!")
    
    eta <- X %*% beta + alpha.v[panel]
    etaM <- X %*% gamma[-1] + gamma[1]
    
    y[, i] <- rbinom(n, size = 1, prob = pnorm(eta))
    M[, i] <- rbinom(n, size = 1, prob = plogis(etaM))
    out[, i] <- ifelse(M[, i] == 0, y[, i], rep(NA, n))
  }  
  
  attr(out, "beta") = beta
  attr(out, "gamma") = c(gamma, 0)
  attr(out, "seed") = seed
  attr(out, "M") = M
  attr(out, "X") = X
  attr(out, "panel") = panel
  attr(out, "m") = m
  attr(out, "sigma2u") = 1/1.6^2
  
  #matrix of dimension (nxNsim)
  return(out)  
}

## Fixed effects
simuMCAR.probit_fe <- function(X, panel, beta, alpha = NULL, 
                            gamma = c(0, 1), Nsim = 1, seed = 123) {
  if (is.null(seed)) seed <- .Random.seed
  set.seed(seed)
  
  n <- nrow(X)                
  q <- length(unique(panel))
  m <- tapply(rep(1, nrow(X)), panel, sum)
  
  if (is.null(alpha)) alpha <- tapply(X[, 1], panel, mean) + rnorm(q)
  alpha.v <- as.vector(alpha)
  if (length(alpha) !=  q) stop("Wrong length of alpha!")
  if (length(gamma) !=  length(beta) + 1) stop("Wrong length of gamma!")
  
  eta <- X %*% beta + alpha.v[panel]
  etaM <- X %*% gamma[-1] + gamma[1]
  
  y <- matrix(rbinom(n*Nsim, size = 1, prob = rep(pnorm(eta), Nsim)), 
              ncol = Nsim)
  M <- matrix(rbinom(n*Nsim, size = 1, prob = rep(plogis(etaM), Nsim)), 
              ncol = Nsim)
  out <- matrix(ifelse (M == 0, as.vector(y), rep(NA, n)), ncol = Nsim)
  
  attr(out, "beta") <- beta
  attr(out, "alpha") <- alpha
  attr(out, "gamma") <- c(gamma, 0)
  attr(out, "p.i") <- NULL
  attr(out, "seed") <- seed
  attr(out, "M") <- M
  attr(out, "X") <- X
  attr(out, "panel") <- panel
  attr(out, "m") <- m
  
  #matrix of dimension (nxNsim)
  return(out)  
}

### MNAR
## Random effects
simuMNAR.probit <- function(X, panel, beta, gamma=c(0,0.3,2), 
                            Nsim = 1, seed = 123) {
  if (is.null(seed)) seed = .Random.seed
  set.seed(seed)
  
  n <- nrow(X)                #sum(m_i)
  q <- length(unique(panel))  #N
  m <- tapply(rep(1, nrow(X)), panel, sum)   #m_i
  
  yC <- M <- out <-  matrix(0, ncol = Nsim, nrow = n)
  
  for (i in 1:Nsim){
    alpha <- rnorm(q, mean = -0.35, sd = 1)
    alpha.v <- as.vector(alpha)/1.6
    if(length(beta) != ncol(X)) stop("Wrong length of beta!")
    if(length(gamma) != length(beta) + 2) stop("Wrong length of gamma!")
    
    eta <- X %*% beta + alpha.v[panel]
    yC[, i] <- rbinom(n, size = 1, prob = pnorm(eta))
    omega <- as.vector(X %*% gamma[-c(1, length(gamma))]) + 
      rep(gamma[1], n) + gamma[length(gamma)]*as.vector(yC[, i])
    
    M[, i] <- rbinom(n, size = 1, prob = plogis(omega))
    out[, i] <- ifelse(M[, i] == 0, yC[, i], rep(NA, n))
  }
  
  attr(out, "beta") = beta
  attr(out, "gamma") = gamma
  attr(out, "seed") = seed
  attr(out, "yC") = yC
  attr(out, "M") = M
  attr(out, "X") = X
  attr(out, "panel") = panel
  attr(out, "m") = m
  attr(out, "sigma2u") = 1/1.6^2
  
  #matrix of dimension (nxNsim)
  return(out)  
}

## Fixed effects
simuMNAR.probit_fe <- function(X, panel, beta, alpha = NULL, 
                            gamma = c(0, 0.3, 2), 
                            Nsim = 1, seed = 123) {
  if (is.null(seed)) seed = .Random.seed
  set.seed(seed)
  
  n <- nrow(X)                
  q <- length(unique(panel))  
  m <- tapply(rep(1, nrow(X)), panel, sum)   
  
  if (is.null(alpha)) alpha <- (tapply(X[, 1], panel, mean) + 
                                  rnorm(q))/1.6
  alpha.v <- as.vector(alpha)
  if (length(beta) !=  ncol(X)) stop ("Wrong length of beta!")
  if (length(alpha) !=  q) stop ("Wrong length of alpha!")
  if (length(gamma) !=  length(beta) + 2) stop ("Wrong length of gamma!")
  
  eta <- X %*% beta + alpha.v[panel]
  yC <- matrix(rbinom(n*Nsim, size = 1, prob = rep(pnorm(eta), 
                                                   Nsim)), ncol = Nsim)
  
  omega <- rep(as.vector(X %*% gamma[-c(1, length(gamma))]), Nsim) + 
    rep(gamma[1], n*Nsim) + gamma[length(gamma)]*as.vector(yC)
  M <- matrix(rbinom(n*Nsim, size = 1, prob = plogis(omega)), 
              ncol = Nsim)
  
  out <- matrix(ifelse (as.vector(M) == 0, as.vector(yC), 
                        rep(NA, n*Nsim)), ncol = Nsim)
  
  attr(out, "beta") <- beta
  attr(out, "alpha") <- alpha
  attr(out, "gamma") <- gamma
  attr(out, "seed") <- seed
  attr(out, "yC") <- yC
  attr(out, "M") <- M
  attr(out, "X") <- X
  attr(out, "panel") <- panel
  attr(out, "m") <- m
  
  #matrix of dimension (nxNsim)
  return(out)  
}

### negative MCAR profile log-likelihood
MdProbitPL <- function(beta, noMDy, noMDx, noMDpanel)  { 
  alpha <- dynProbitAlpha(noMDx, noMDpanel, noMDy, beta, 
                          rep(0, length(unique(noMDpanel)))) 
  eta <- noMDx %*% beta + alpha[noMDpanel]
  p <- p.range(pnorm(eta))
  out <-sum(noMDy*log(p) + (1 - noMDy)*log(1 - p))
  return(-out)
}

### negative Severini's MPL -- no MC simulation for I term
unbMdProbitMPL <- function(beta, noMDx, noMDy, 
                           noMDpanel, beta.mle, alpha.mle) {   
  q <- length(unique(noMDpanel))   
  ng <- tapply(rep(1, nrow(noMDx)), noMDpanel, sum)   
  out <- .C("stat_probit_MPL", 
    as.double(beta), 
    as.integer(length(beta)), 
    as.double(noMDx),   
    as.integer(nrow(noMDx)), 
    as.double(noMDy), 
    as.integer(ng),    
    as.integer(q),     
    as.integer(max(ng)), 
    as.double(beta.mle), 
    as.double(alpha.mle), 
    out = as.double(0.0))$out
  return(-out)
}

### negative MCAR MCMPL
unbMdProbitMPLS4 <- function(beta, noMDx, X, noMDy, noMDpanel, 
                             panel, R = 200, seed = 321, beta.mle, 
                             alpha.mle, p.logit.hat) {   
  set.seed(seed)
  q <- length(unique(noMDpanel))   
  ng <- tapply(rep(1, nrow(noMDx)), noMDpanel, sum)  
  m <- tapply(rep(1, nrow(X)), panel, sum)  
  out <- .C("unb_probitMD_MPL_simu4", 
    as.double(beta), 
    as.integer(length(beta)), 
    as.double(noMDx),   
    as.double(X),      
    as.integer(nrow(noMDx)), 
    as.integer(m), 
    as.integer(sum(m)), 
    as.integer(max(m)), 
    as.double(noMDy), 
    as.integer(ng),   
    as.integer(q),     
    as.integer(max(ng)), 
    as.integer(R), 
    as.double(beta.mle), 
    as.double(alpha.mle), 
    as.double(p.logit.hat), 
    out = as.double(0.0))$out
  return(-out)
}

### observed negative MNAR profile log-likelihood, theta = (beta, gamma)
NIprobitPL_noG1 <-  function(theta, Xe, y_noNA, M, panel) { 
  beta <- theta[1:ncol(Xe)]
  gamma <- c(0, theta[-(1:ncol(Xe))])
  alpha <- NIprobitAlpha_noG1(Xe, panel, y_noNA, M, theta, 
                             rep(0, length(unique(panel))))
  eta <- Xe %*% beta+alpha[panel]
  omega <- Xe %*% gamma[- c(1, length(gamma))] + rep(gamma[1], nrow(Xe)) + 
    gamma[length(gamma)]*y_noNA*(1 - M)
  omegaM <- Xe %*% gamma[- c(1, length(gamma))] + rep(gamma[1], nrow(Xe)) + 
    gamma[length(gamma)]
  mu <- p.range(pnorm(eta))
  p <- p.range(plogis(omega))
  pM <- p.range(plogis(omegaM))
  out <- sum((1 - M)*(y_noNA*log(mu) + (1 - y_noNA)*log(1 - mu) + log(1 - p)) +
      M*log((1 - mu)*p + mu*pM))
  return(-out)
}

### constrained estimates of lambda under MNAR model
NIprobitAlpha_noG1 <- function(Xe, panel, y_noNA, 
                               M, theta, alpha.in) {   
  beta <- theta[1:ncol(Xe)]
  gamma <- c(0, theta[-(1:ncol(Xe))])
  q <- length(unique(panel)) 
  ng <- tapply(rep(1, nrow(Xe)), panel, sum) 
  .C("NI_probit_alpha", 
    as.double(alpha.in), 
    as.double(beta), 
    as.double(Xe), 
    as.integer(length(beta)), 
    as.double(gamma), 
    as.integer(length(gamma)), 
    as.double(y_noNA), 
    as.integer(M), 
    as.integer(nrow(Xe)), 
    as.integer(ng), 
    as.integer(q), 
    as.integer(max(ng)), 
    as.double(10^-6), 
    as.integer(100), 
    alpha = as.double(rep(0.0, q)))$alpha
}

### negative MNAR MCMPL
unbNIprobitMPLS_noG1 <- function(theta, X, y_noNA, M, panel, 
                                 R = 500, seed = 321, theta.mle, 
                                 alpha.mle) {   
  set.seed(seed)
  beta <- theta[1:ncol(X)]
  gamma <- c(0, theta[-(1:ncol(X))])
  betahat <- theta.mle[1:ncol(X)]
  gammahat <- c(0, theta.mle[-(1:ncol(X))])
  q <- length(unique(panel))   
  m <- tapply(rep(1, nrow(X)), panel, sum)   
  out <- .C("unb_probitNI_MPL_simu", 
    as.double(beta), 
    as.integer(length(beta)), 
    as.double(gamma), 
    as.integer(length(gamma)), 
    as.double(X),      
    as.integer(q), 
    as.integer(m), 
    as.integer(sum(m)), 
    as.integer(max(m)), 
    as.double(y_noNA), 
    as.integer(M), 
    as.integer(R), 
    as.double(betahat), 
    as.double(alpha.mle), 
    as.double(gammahat), 
    out = as.double(0.0))$out
  return(-out)
}

probit.simula_noG1 <- function(data) {
  M <- attr(data, "M")
  X <- attr(data, "X")
  yC <- attr(data, "yC")
  panel <- attr(data, "panel")
  
  n <- dim(data)[1]
  Nsim <- dim(data)[2]
  q <- length(unique(panel))               
  m <- tapply(rep(1, nrow(X)), panel, sum)  
  ncov <- ncol(X)                              
  
  # prepare output vectors
  betahat0 <- matrix(NA, nrow = ncov, ncol = Nsim)
  betahat0.SE <- matrix(NA, nrow = ncov, ncol = Nsim)
  betahatMPL0 <- matrix(NA, nrow = ncov, ncol = Nsim)
  betahatMPL0.SE <- matrix(NA, nrow = ncov, ncol = Nsim)
  gammahat0 <- matrix(NA, nrow = ncov, ncol = Nsim)
  gammahatMPL.NA.SE <- matrix(NA, nrow = ncov + 1, ncol = Nsim)
  betahat.NA <- matrix(NA, nrow = ncov, ncol = Nsim)
  betahat.NA.SE <- matrix(NA, nrow = ncov, ncol = Nsim)
  gammahat.NA <- matrix(NA, nrow = ncov + 1, ncol = Nsim)
  gammahat.NA.SE <- matrix(NA, nrow = ncov + 1, ncol = Nsim)
  betahatMPL.NA <- matrix(NA, nrow = ncov, ncol = Nsim)
  betahatMPL.NA.SE <- matrix(NA, nrow = ncov, ncol = Nsim)
  gammahatMPL.NA <- matrix(NA, nrow = ncov + 1, ncol = Nsim)
  gammahatMPL.NA.SE <- matrix(NA, nrow = ncov + 1, ncol = Nsim)
  betahatMPL3 <- matrix(NA, nrow = ncov, ncol = Nsim)
  betahatMPL3.SE <- matrix(NA, nrow = ncov, ncol = Nsim)
  N.inf <- rep(NA, Nsim)
  mleErrNA <- 0
  mleMPLerr <- 0
  SEnaErr <- 0
  SEmplErr <- 0
  for (i in 1:Nsim) {
    # i-th dataset
    data.i <- data[, i]
    M.ii <- M[, i]
    yC.i <- yC[, i]
    
    ## remove uninformative strata
    mean.y <- tapply(data.i, panel, mean, na.rm = T)
    cond <- !((mean.y ==  0) | (mean.y ==  1) | (is.nan(mean.y) ==  1))
    ind <- match(panel, names(cond))
    sele <- cond[ind]
    
    y.i <- data.i[sele]
    X.i <- as.matrix(X[sele, ])
    M.i <- M.ii[sele]
    N.inf[i] <- sum(cond)
    
    glm.out <- glm.fit(model.matrix(M.ii ~ X - 1), M.ii, 
                       family = binomial(link = "logit"))
    gammahat0[, i] <- as.vector(coef(glm.out))
    plogit.hat <- fitted(glm.out)[sele]
    
    ## new panel indicator
    panel.i <- get.g(panel[sele])
    
    ## eliminate NA
    noMisData <- cbind(X.i, y.i, panel.i, M.i)
    noMisData <- noMisData[M.i ==  0, ]
    noMD.y <- noMisData[, ncov + 1]
    noMD.X <- as.matrix(noMisData[, 1:ncov])
    noMD.panel <- noMisData[, ncov + 2]
    
    ## response vector with 0 in place of NA
    NA0.y <- ifelse (M.i ==  1, rep(0, length(y.i)), y.i)
    
    if (i%%100 ==  0) print(i) # monitor progress
    
    ### MCAR MLE (complete units only)
    mle.prof <- tryCatch(nlminb(rep(0, ncov), MdProbitPL, 
                                noMDy = noMD.y, noMDx = noMD.X, 
      noMDpanel = noMD.panel), error = function(e) print("error MLE"))
    if (is.character(mle.prof)) {
      betahat0[, i] <- rep(NA, ncov)
      betahat0.SE[, i] <- rep(NA, ncov)
      betahatMPL0[, i] <- rep(NA, ncov)
      betahatMPL0.SE[, i] <- rep(NA, ncov)
      betahatMPL3[, i] <- rep(NA, ncov)
      betahatMPL3.SE[, i] <- rep(NA, ncov)
    }
    else {
      betahat0[, i] <- mle.prof$par
      betahat0.SE[, i] <- diag(solve(numDeriv::hessian(MdProbitPL, 
                                betahat0[, i], noMDy = noMD.y, 
        noMDx = noMD.X, noMDpanel = noMD.panel)))^0.5
      alphahat <- dynProbitAlpha(noMD.X, noMD.panel, noMD.y, betahat0[, i], 
        rep(0, length(unique(noMD.panel))))
      
    ### Severini's MPL (complete units only)
    mle.MPL0 <- tryCatch(nlminb(betahat0[, i], unbMdProbitMPL, 
                                noMDx = noMD.X, noMDy = noMD.y, 
                                noMDpanel = noMD.panel, 
                                beta.mle = betahat0[, i], 
                                alpha.mle = alphahat), 
                         error = function(e)print("error MPL0"))
      if (is.character(mle.MPL0)) {
        betahatMPL0[, i] <- rep(NA, ncov)
        betahatMPL0.SE[, i] <- rep(NA, ncov)
      }
      else {
        betahatMPL0[, i] <- mle.MPL0$par
        betahatMPL0.SE[, i] <- diag(solve(numDeriv::hessian(unbMdProbitMPL, 
                                  betahatMPL0[, i], noMDx = noMD.X, 
                                  noMDy = noMD.y, noMDpanel = noMD.panel, 
                                  beta.mle = betahat0[, i], 
                                  alpha.mle = alphahat)))^0.5
      }
      
    ### MCAR MCMPL
    mle.MPL3 <- tryCatch(nlminb(betahat0[, i], unbMdProbitMPLS4, 
                                noMDx = noMD.X, X = X.i, noMDy = noMD.y, 
                                noMDpanel = noMD.panel, panel = panel.i, 
                                R = 500, beta.mle = betahat0[, i], 
                                alpha.mle = alphahat, p.logit.hat = plogit.hat), 
                         error = function(e) print("error MPL3"))
    if (is.character(mle.MPL3)) {
      betahatMPL3[, i] <- rep(NA, ncov)
      betahatMPL3.SE[, i] <- rep(NA, ncov)
    }
    else {
      betahatMPL3[, i] <- mle.MPL3$par
      betahatMPL3.SE[, i] <- diag(solve(numDeriv::hessian(unbMdProbitMPLS4, 
                                 betahatMPL3[, i], noMDx = noMD.X, X = X.i, 
                                 noMDy = noMD.y, noMDpanel = noMD.panel, 
                                 panel = panel.i, R = 500, beta.mle = betahat0[, i], 
        alpha.mle = alphahat, p.logit.hat = plogit.hat)))^0.5
    }

  }
      ### observed MNAR profile log-likelihood
      mleNA.out <- tryCatch(optim(rep(0, 2*ncov + 1), NIprobitPL_noG1, 
                                  Xe = X.i, y_noNA = NA0.y, M = M.i, 
                                  panel = panel.i, hessian = T), 
                            error = function(e) print("error mleNA"))
      if (is.character(mleNA.out)){
        gammahat.NA[, i] <- rep(NA, ncov + 1)
        gammahat.NA.SE[, i] <- rep(NA, ncov + 1)
        betahat.NA[, i] <- rep(NA, ncov)
        betahat.NA.SE[, i] <- rep(NA, ncov)
        gammahatMPL.NA[, i] <- rep(NA, ncov + 1)
        gammahatMPL.NA.SE[, i] <- rep(NA, ncov + 1)
        betahatMPL.NA[, i] <- rep(NA, ncov)
        betahatMPL.NA.SE[, i] <- rep(NA, ncov)
        mleErrNA <- mleErrNA+1
      }
      else {
        gammahat.NA[, i] <- mleNA.out$par[-(1:ncov)]
        betahat.NA[, i] <- mleNA.out$par[1:ncov]
        SEna <- tryCatch(as.vector(diag(solve(numDeriv::hessian(
          NIprobitPL_noG1, x = mleNA.out$par, Xe = X.i, 
          y_noNA = NA0.y, M = M.i, panel = panel.i)))^.5), 
          error = function(e) print("error SEna"))
        if (is.character(SEna)){
          gammahat.NA.SE[, i] <- rep(NA, ncov + 1)
          betahat.NA.SE[, i] <- rep(NA, ncov)
          SEnaErr <- SEnaErr + 1
        }
        else {
          gammahat.NA.SE[, i] <- SEna[-(1:ncov)]
          betahat.NA.SE[, i] <- SEna[1:ncov]
        }

        alphahat <- NIprobitAlpha_noG1(X.i, panel.i, NA0.y, 
                                       M.i, mleNA.out$par, 
                                     rep(0, length(unique(panel.i))))
     ### MNAR MCMPL
        MPL.out <- tryCatch(optim(mleNA.out$par, unbNIprobitMPLS_noG1,
                                  y_noNA = NA0.y, X = X.i, panel = panel.i,
                                  M = M.i, theta.mle = mleNA.out$par, 
                                alpha.mle = alphahat), 
                            error = function(e) print("error MPL"))
        if (is.character(MPL.out)){
          gammahatMPL.NA[, i] <- rep(NA, ncov + 1)
          gammahatMPL.NA.SE[, i] <- rep(NA, ncov + 1)
          betahatMPL.NA[, i] <- rep(NA, ncov)
          betahatMPL.NA.SE[, i] <- rep(NA, ncov)
          mleMPLerr <- mleMPLerr + 1
        }
        else {
          gammahatMPL.NA[, i] <- MPL.out$par[-(1:ncov)]
          betahatMPL.NA[, i] <- MPL.out$par[1:ncov]

          SEmpl <- tryCatch(as.vector(diag(solve(
            numDeriv::hessian(unbNIprobitMPLS_noG1,
                              MPL.out$par, y_noNA = NA0.y, X = X.i, 
                              panel = panel.i, M = M.i,
                              theta.mle = mleNA.out$par, alpha.mle = alphahat)))^0.5), 
                          error = function(e) print("error SEmpl"))
          if (is.character(SEmpl)){
            gammahatMPL.NA.SE[, i] <- rep(NA, ncov + 1)
            betahatMPL.NA.SE[, i] <- rep(NA, ncov)
            SEmplErr <- SEmplErr + 1
          }
          else {
            gammahatMPL.NA.SE[, i] <- SEmpl[-(1:ncov)]
            betahatMPL.NA.SE[, i] <- SEmpl[1:ncov]
          }
        }
    }     
  }
  
  list(betahat.NA = betahat.NA, betahat.NA.SE = betahat.NA.SE, betahat0 = betahat0, 
    betahat0.SE = betahat0.SE, betahatMPL0 = betahatMPL0, betahatMPL0.SE = betahatMPL0.SE, 
    betahatMPL3 = betahatMPL3, betahatMPL3.SE = betahatMPL3.SE, 
    gammahat.NA = gammahat.NA, gammahat.NA.SE = gammahat.NA.SE, N.inf = N.inf, 
    betahatMPL.NA = betahatMPL.NA, betahatMPL.NA.SE = betahatMPL.NA.SE, 
    gammahatMPL.NA = gammahatMPL.NA, gammahatMPL.NA.SE = gammahatMPL.NA.SE, 
    beta = attr(data, "beta"), alpha = attr(data, "alpha"), gamma = attr(data, "gamma"), 
    q = q, m = m, X = X, M = M, mleErrNA = mleErrNA, mleMPLerr = mleMPLerr, SEmplErr = SEmplErr, 
    SEnaErr = SEnaErr, seed = attr(data, "seed"), gammahat0 = gammahat0)
}

### GEE
probit_simuGEE_noG1 <- function(data) {
  require(gee)
  X <- attr(data, "X")
  panel <- attr(data, "panel")
  
  n <- dim(data)[1]
  Nsim <- dim(data)[2]
  q <- length(unique(panel))                #N
  m <- tapply(rep(1, nrow(X)), panel, sum)   #m_i
  ncov <- ncol(X)                              #Ncov
  
  # prepare output vectors
  betahat.GEEind <- matrix(NA, nrow = ncov, ncol = Nsim)
  betahat.GEE.SEind <- matrix(NA, nrow = ncov, ncol = Nsim)
  betahat.GEE.robSEind <- matrix(NA, nrow = ncov, ncol = Nsim)
  betahat.GEEexc <- matrix(NA, nrow = ncov, ncol = Nsim)
  betahat.GEE.SEexc <- matrix(NA, nrow = ncov, ncol = Nsim)
  betahat.GEE.robSEexc <- matrix(NA, nrow = ncov, ncol = Nsim)
  N.inf <- rep(NA, Nsim)
  err_ind <- 0
  err_exc <- 0
  
  for (i in 1:Nsim) {
    # i-th dataset
    y <- data[, i]
    
    if (i%%100 == 0) print(i) # monitor progress
    
    gee.out_ind <- tryCatch(gee(y ~ X, id = panel, na.action = na.omit, 
                                family = binomial(link = "probit"), 
                                corstr = "independence"), 
                            error = function(e) print("error GEEind"))
    if (is.character(gee.out_ind)) {
      betahat.GEEind[, i] <- rep(NA, ncov)
      betahat.GEE.SEind[, i] <- rep(NA, ncov)
      betahat.GEE.robSEind[, i] <- rep(NA, ncov)
      err_ind <- err_ind + 1
    }
    else {
      betahat.GEEind[, i] <- summary(gee.out_ind)$coefficients[-1, 1]
      betahat.GEE.SEind[, i] <- summary(gee.out_ind)$coefficients[-1, 2]
      betahat.GEE.robSEind[, i] <- summary(gee.out_ind)$coefficients[-1, 4]
    }
    
    gee.out_exc <- tryCatch(gee(y ~ X, id = panel, na.action = na.omit, 
                                family = binomial(link = "probit"), 
                                corstr = "exchangeable"), 
                            error = function(e) print("error GEEexc"))
    if (is.character(gee.out_exc)) {
      betahat.GEEexc[, i] <- rep(NA, ncov)
      betahat.GEE.SEexc[, i] <- rep(NA, ncov)
      betahat.GEE.robSEexc[, i] <- rep(NA, ncov)
      err_exc <- err_exc + 1
    }
    else {
      betahat.GEEexc[, i] <- summary(gee.out_exc)$coefficients[-1, 1]
      betahat.GEE.SEexc[, i] <- summary(gee.out_exc)$coefficients[-1, 2]
      betahat.GEE.robSEexc[, i] <- summary(gee.out_exc)$coefficients[-1, 4]
    }
    
  }
  
  list(betahat.GEEind = betahat.GEEind, betahat.GEE.SEind = betahat.GEE.SEind, 
       betahat.GEE.robSEind = betahat.GEE.robSEind, 
       betahat.GEEexc = betahat.GEEexc, betahat.GEE.SEexc = betahat.GEE.SEexc, 
       betahat.GEE.robSEexc = betahat.GEE.robSEexc, 
       beta = attr(data, "beta"), gamma = attr(data, "gamma"), q = q, m = m, 
       err_exc = err_exc, err_ind = err_ind, seed = attr(data, "seed"), data = data)
}

### simulate MCAR data with T = 10, N = 250
nsimu <- 2000

N <- 250
T <- 10
ncov <- 1
panelInd <- rep(1:N, each = T)

set.seed(6)
X <- matrix(rnorm(N * T * ncov, mean = -0.35), 
              nrow = N * T, ncol = ncov)

y10250 <- simuMCAR.probit(X = X, panel = panelInd, 
                    beta = 1/1.6, alpha = NULL, gamma = c(0, 2.5), 
                    Nsim = nsimu, seed = 134)

res10250MCAR <- probit.simula_noG1(y10250)
res10250GEE <- probit_simuGEE_noG1(y10250)

### simulate MNAR data with T = 4, N = 50
nsimu <- 2000

N <- 50
T <- 4
ncov <- 1
panelInd <- rep(1:N, each = T)

set.seed(6)
X <- matrix(rnorm(N * T * ncov, mean = -0.35), nrow = N * T, 
              ncol = ncov)

y450 <- simuMNAR.probit(X = X, panel = panelInd, beta = 1/1.6, 
                          alpha = NULL, gamma = c(0, 5, 1), 
                          Nsim = nsimu, seed = 134)

resNI450_noG1 <- probit.simula_noG1(y450)
res450GEE <- probit_simuGEE_noG1(y450)