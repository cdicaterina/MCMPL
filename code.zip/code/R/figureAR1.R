############ Figure S1 - Supplementary material ###############

library("ggplot2")
require("plyr")
require("dplyr")
library("extrafont")
#font_install('fontcm')

# new panel indicator
get.g <- function(g) { 
  n <- length(g)
  out <- rep(0, n)
  uni <- unique(g)
  N <- length(unique(g))
  for (i in 1:N) {
    cond <- (g == uni[i])
    ind <- (1:n)[cond]
    out[ind] <- i
  }
  return(out)
}

# sum of squared differences
SS_rho <- function(rho, data) {
  T <- ncol(data) - 1
  w <- data[, -1, drop = FALSE] - rho*data[, - ncol(data), 
                                           drop = FALSE]
  lambdahat_rho <- rowMeans(w)
  ss <- sum((w - lambdahat_rho)^2)
  ss
}

### negative PL as function of rho
nloglP <- function(rho, data) {
  N <- nrow(data)
  T <- ncol(data)-1
  sigma2hat.rho <- SS_rho(rho, data)/(N*T)
  0.5 * N * T * log(sigma2hat.rho)
}

### negative PL as function of psi = (rho, sigma2)
PLpsi <- function(psi, data) {
  rho <- psi[1]
  sigma2 <- psi[2]
  N <- nrow(data)
  T <- ncol(data) - 1
  0.5 * N * T* log(sigma2) + 0.5 * SS_rho(rho, data)/sigma2
}

# analytical MLE
ar.mle <- function(data) {
  N <- nrow(data)
  T <- ncol(data) - 1
  rhohat.num <- sum(apply(data, 1, function(y) (sum(y[-1]*y[-length(y)]) -
                                                  T * mean(y[-1]) * mean(y[-length(y)]))))
  rhohat.den <- sum(apply(data, 1, function(y) (sum(y[-length(y)]^2) - 
                                                  T*(mean(y[-length(y)]))^2)))
  rhohat <- rhohat.num/rhohat.den
  w <- data[, -1, drop = FALSE] - rhohat * data[, -ncol(data), drop = FALSE]
  muhat <- rowMeans(w)
  sigma2hat <- SS_rho(rhohat, data)/(N*T)
  
  list(rhohat = rhohat, sigma2hat = sigma2hat, 
       muhat = muhat)
}

## Istar as function of rho only
Istar <- function(rho, rhohat, lambdahat, lambdahat_rho, 
                  sigma2hat, R, data, seed) {
  N <- nrow(data)
  T <- ncol(data) - 1
  ystar <- array(NA, dim = c(N, T+1, R))
  set.seed(seed)
  for (j in 1:R) {
    yst <- matrix(NA, nrow = N, ncol = (T+1))
    yst[, 1] <- data[, 1]
    for (i in 1:T) yst[, i+1] <- lambdahat + rhohat*yst[, i] + 
      rnorm(N, mean = 0, sd = sqrt(sigma2hat))
    ystar[, , j] <- yst
  }
  out = .C("Imumu", 
           as.double(rho), 
           as.double(rhohat), 
           as.double(lambdahat), 
           as.double(lambdahat_rho), 
           as.double(ystar), 
           as.integer(N), 
           as.integer(T), 
           as.integer(R), 
           output = as.double(rep(0, N)))$output
  out
}

### negative MPL as function of rho
nloglPM1 <- function(rho, data, ybar0, psi.hat, 
                     mu.hat, R = 500, seed = 123) {
  N <- nrow(data)
  T <- ncol(data) - 1
  if(is.null(seed)) seeds <- .Random.seed  else seeds <- seed
  mu.hat.rho <- mu.hat + (psi.hat[1] - rho)*ybar0
  I.star <- Istar(rho = rho, rhohat = psi.hat[1], 
                  lambdahat = mu.hat, lambdahat_rho = mu.hat.rho, 
                  sigma2hat = psi.hat[2], R = R, data = data, seed = seeds)
  0.5 * N * (T - 1) * log(SS_rho(rho, data)) + sum(log(I.star))
}

### negative MPL as function of psi = (rho, sigma2)
MPLpsi <- function(psi, data, ybar0, psihat, lambdahat, 
                   R = 500, seed = 123) {
  rho <- psi[1]
  sigma2 <- psi[2]
  N <- nrow(data)
  T <- ncol(data) - 1
  if(is.null(seed)) seeds <- .Random.seed[1]  else seeds <- seed
  lambdahat_rho <- lambdahat + (psihat[1] - rho)*ybar0
  Istar_rho <- Istar(rho = rho, rhohat = psihat[1], 
                     lambdahat = lambdahat, lambdahat_rho = lambdahat_rho, 
                     sigma2hat = psihat[2], R = R, data = data, seed = seeds)
  PLpsi(psi, data) - 0.5 * N * log(T/sigma2) + sum(log(Istar_rho)) - N*log(sigma2)
}

AR.gen.dati <- function(rho, sigma2, mu, y0, T, Nsim, 
                        seed = NULL) {
  if (is.null(seed)) seed <- .Random.seed
  set.seed(seed)
  
  N <- length(mu)
  out <- array(NA, dim = c(N, T + 1, Nsim))
  
  for (j in 1:Nsim) {
    ystar <- matrix(NA, nrow = N, ncol = T + 1)
    ystar[, 1] <- y0
    for (i in 1:T) ystar[, i + 1] <- mu + rho * ystar[, i] + 
      rnorm(N, mean = 0, sd = sqrt(sigma2))
    out[, , j] <- ystar
  }
  
  #some attributes of the generated data
  attr(out, "rho") <- rho
  attr(out, "sigma2") <- sigma2
  attr(out, "mu") <- mu
  attr(out, "seed") <- seed
  
  #array of dimension (N, T + 1, Nsim)
  out
}

nloglP.v <- Vectorize(nloglP, "rho")
nloglPM1.v <- Vectorize(nloglPM1, "rho")

#### AR(1)
dyn.load("IstarAR1.so")
rho0 <- c(0.5, 0.9)
N <- c(250, 1000)
T <- 4

all.fP <- function(x, rho0, N, T = 4) {
  y1 <- AR.gen.dati(rho = rho0, sigma2 = 1, mu = rnorm(N, mean = 1, sd = 1), 
                    y0 = rep(0, N), T = T, Nsim = 1, seed = 321)
  dati.i <- matrix(y1, N, T + 1)
  ybar.0 <- apply(dati.i, 1, function(y) mean(y[1:T]))
  mle <- ar.mle(dati.i)
  mu.hat <- mle$muhat
  r.hat <- mle$rhohat
  s2.hat <- mle$sigma2hat
  
  - nloglP.v(x, data = dati.i) + nloglP.v(r.hat, data = dati.i)
}

all.fMP <- function(x, rho0, N, T = 4) {
  y1 = AR.gen.dati(rho = rho0, sigma2 = 1, mu = rnorm(N, mean = 1, sd = 1), 
                   y0 = rep(0, N), T = T, Nsim = 1, seed = 321)
  dati.i <- matrix(y1, N, T + 1)
  ybar.0 <- apply(dati.i, 1, function(y) mean(y[1:T]))
  mle <- ar.mle(dati.i)
  mu.hat <- mle$muhat
  r.hat <- mle$rhohat
  s2.hat <- mle$sigma2hat
  
  mle.M1 <- optimize(nloglPM1, c(-1.5, 1.5), data = dati.i, 
                     ybar0 = ybar.0, psi.hat = c(r.hat, s2.hat), mu.hat = mu.hat)
  
  nloglPM1.v(x, data = dati.i, ybar = ybar.0, psi.hat = c(r.hat, s2.hat), 
             mu.hat = mu.hat) + nloglPM1.v(mle.M1$minimum, 
    data = dati.i, ybar = ybar.0, psi.hat = c(r.hat, s2.hat), mu.hat = mu.hat)
}

df1 <- expand.grid(N = c(250, 1000), method = c("pl", "mpl"), 
                   rho0 = 0.5, z = seq(0.1, 1.15, length = 100))
df2 <- expand.grid(N = c(250, 1000), method = c("pl", "mpl"), 
                   rho0 = 0.9, z = seq(0.6, 1.35, length = 100))
df.true <- data.frame(rbind(df1, df2))

df.true$setting <- paste0("setting", seq_len(nrow(df.true)))

df.true <- ddply(df.true, ~ setting, function(dfc) {
  N <- dfc$N
  rho0 <- dfc$rho0
  method <- dfc$method
  z <- dfc$z
  loglik <- switch(as.character(method), 
    "pl" = all.fP(x = z, rho0 = rho0, N = N, T = 4), 
    "mpl" = all.fMP(x =  z, rho0 = rho0, N = N, T = 4))
  data.frame(z = z, N = N, rho0 = rho0, method = method, loglik = loglik)
})


df.true$method <- factor(df.true$method, levels = c("pl", "mpl"), 
                         ordered = TRUE)
df.true$Nstring <- paste0("N = ", df.true$N)
df.true$rhostring <- paste0("rho = ", df.true$rho0)
df.true$Nstring <- factor(df.true$Nstring, levels = c("N = 250", "N = 1000"), 
                          labels = c(expression(paste(italic(T) == 4, ", ", 
                          italic(N) == 250)), expression(paste(italic(T) == 4, 
                                                  ", ", italic(N) == 1000))))
df.true$rhostring <- factor(df.true$rhostring, levels = c("rho = 0.5", "rho = 0.9"),
                            labels = c("rho ==  0.5", "rho ==  0.9"), ordered = TRUE)

plot_ar1.true <- ggplot(df.true, aes(z, loglik, group = method, 
                                     col = method, lty = method)) +
  geom_hline(aes(yintercept = - qchisq(0.95, 1)/2), color = 1, 
             alpha = 0.25) + geom_vline(aes(xintercept = rho0), 
                  color = "red", alpha = 0.25, lty = "dotted") +
                    geom_line(alpha = 0.5) + coord_cartesian(ylim = c(-31, 1.5)) +
  facet_grid(Nstring ~ rhostring, scales = "free", labeller = label_parsed) +
  labs(y = "Relative log-likelihood", x = expression(rho)) +
  theme_bw() +
  theme(text = element_text(size = 12, family = "CM Roman")) +
  theme(legend.position = "top", panel.grid.major.y = element_blank(), 
        panel.grid.minor.y = element_blank(), 
    panel.grid.minor.x = element_blank(), strip.background = element_blank(), 
    panel.grid.major.x = element_blank(), legend.margin = margin(4, 0, 0, 0), 
    legend.box.margin = margin(-10, -10, -10, -10), legend.text = element_text(size = 12)) +
  scale_linetype_manual(name = "", values = c(2, 1), 
    labels = c(expression(paste(italic(l)[italic(P)]^rho, (rho))), 
               expression(paste(italic(l)[italic(M)^list("*")]^rho, (rho))))) +
  scale_colour_manual(name = "", values = c(6, 4), 
    labels = c(expression(paste(italic(l)[italic(P)]^rho, (rho))), 
               expression(paste(italic(l)[italic(M)^list("*")]^rho, (rho)))))



# pdf("ggAR1coldash.pdf", width = 7, height = 7/sqrt(2))
# print(plot_ar1.true)
# dev.off()
# embed_fonts("ggAR1coldash.pdf", outfile = "ggAR1coldash.pdf")
# system("pdf2ps ggAR1coldash.pdf ggAR1coldash.eps")