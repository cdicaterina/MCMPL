### Nonstationary AR(1) ###
### simulations ###

dyn.load("IstarAR1.so")

# new panel indicator
get.g <- function(g) { 
  n <- length(g)
  out <- rep(0, n)
  uni <- unique(g)
  N <- length(unique(g))
  for (i in 1:N) {
    cond <- (g == uni[i])
    ind <- (1:n)[cond]
    out[ind] <- i
  }
  return(out)
}

# sum of squared differences
SS_rho <- function(rho, data) {
  T <- ncol(data) - 1
  w <- data[, -1, drop = FALSE] - rho*data[, - ncol(data), 
                                            drop = FALSE]
  lambdahat_rho <- rowMeans(w)
  ss <- sum((w - lambdahat_rho)^2)
  ss
}

### negative PL as function of rho
nloglP <- function(rho, data) {
  N <- nrow(data)
  T <- ncol(data)-1
  sigma2hat.rho <- SS_rho(rho, data)/(N*T)
  0.5 * N * T * log(sigma2hat.rho)
}

### negative PL as function of psi = (rho, sigma2)
PLpsi <- function(psi, data) {
  rho <- psi[1]
  sigma2 <- psi[2]
  N <- nrow(data)
  T <- ncol(data) - 1
  0.5 * N * T* log(sigma2) + 0.5 * SS_rho(rho, data)/sigma2
}

# analytical MLE
ar.mle <- function(data) {
  N <- nrow(data)
  T <- ncol(data) - 1
  rhohat.num <- sum(apply(data, 1, function(y) (sum(y[-1]*y[-length(y)]) -
                                    T * mean(y[-1]) * mean(y[-length(y)]))))
  rhohat.den <- sum(apply(data, 1, function(y) (sum(y[-length(y)]^2) - 
                                    T*(mean(y[-length(y)]))^2)))
  rhohat <- rhohat.num/rhohat.den
  w <- data[, -1, drop = FALSE] - rhohat * data[, -ncol(data), drop = FALSE]
  muhat <- rowMeans(w)
  sigma2hat <- SS_rho(rhohat, data)/(N*T)
  
  list(rhohat = rhohat, sigma2hat = sigma2hat, 
       muhat = muhat)
}

## Istar as function of rho only
Istar <- function(rho, rhohat, lambdahat, lambdahat_rho, 
                   sigma2hat, R, data, seed) {
  N <- nrow(data)
  T <- ncol(data) - 1
  ystar <- array(NA, dim = c(N, T+1, R))
  set.seed(seed)
  for (j in 1:R) {
    yst <- matrix(NA, nrow = N, ncol = (T+1))
    yst[, 1] <- data[, 1]
    for (i in 1:T) yst[, i+1] <- lambdahat + rhohat*yst[, i] + 
      rnorm(N, mean = 0, sd = sqrt(sigma2hat))
    ystar[, , j] <- yst
  }
  out = .C("Imumu", 
    as.double(rho), 
    as.double(rhohat), 
    as.double(lambdahat), 
    as.double(lambdahat_rho), 
    as.double(ystar), 
    as.integer(N), 
    as.integer(T), 
    as.integer(R), 
    output = as.double(rep(0, N)))$output
  out
}

### negative MPL as function of rho
nloglPM1 <- function(rho, data, ybar0, psi.hat, 
                     mu.hat, R = 500, seed = 123) {
  N <- nrow(data)
  T <- ncol(data) - 1
  if(is.null(seed)) seeds <- .Random.seed  else seeds <- seed
  mu.hat.rho <- mu.hat + (psi.hat[1] - rho)*ybar0
  I.star <- Istar(rho = rho, rhohat = psi.hat[1], 
                  lambdahat = mu.hat, lambdahat_rho = mu.hat.rho, 
                  sigma2hat = psi.hat[2], R = R, data = data, seed = seeds)
  0.5 * N * (T - 1) * log(SS_rho(rho, data)) + sum(log(I.star))
}

### negative MPL as function of psi = (rho, sigma2)
MPLpsi <- function(psi, data, ybar0, psihat, lambdahat, 
                   R = 500, seed = 123) {
  rho <- psi[1]
  sigma2 <- psi[2]
  N <- nrow(data)
  T <- ncol(data) - 1
  if(is.null(seed)) seeds <- .Random.seed[1]  else seeds <- seed
  lambdahat_rho <- lambdahat + (psihat[1] - rho)*ybar0
  Istar_rho <- Istar(rho = rho, rhohat = psihat[1], 
                     lambdahat = lambdahat, lambdahat_rho = lambdahat_rho, 
    sigma2hat = psihat[2], R = R, data = data, seed = seeds)
  PLpsi(psi, data) - 0.5 * N* log(T/sigma2) + sum(log(Istar_rho)) - N*log(sigma2)
}

# data generation (mu and y0 are vectors of length N)
AR.gen.dati <- function(rho, sigma2, mu, y0, T, Nsim, 
                        seed = NULL) {
  if (is.null(seed)) seed <- .Random.seed
  set.seed(seed)
  
  N <- length(mu)
  out <- array(NA, dim = c(N, T + 1, Nsim))
  
  for (j in 1:Nsim) {
    ystar <- matrix(NA, nrow = N, ncol = T + 1)
    ystar[, 1] <- y0
    for (i in 1:T) ystar[, i + 1] <- mu + rho * ystar[, i] + 
      rnorm(N, mean = 0, sd = sqrt(sigma2))
    out[, , j] <- ystar
  }
  
  #some attributes of the generated data
  attr(out, "rho") <- rho
  attr(out, "sigma2") <- sigma2
  attr(out, "mu") <- mu
  attr(out, "seed") <- seed
  
  #array of dimension (N, T + 1, Nsim)
  out
}

AR1simu <- function(dati) {
  
  N <- dim(dati)[1]
  T <- dim(dati)[2] - 1
  Nsim <- dim(dati)[3]
  
  # prepare output vectors
  rhohat <- rhohat.M1 <- rep(NA, Nsim)
  sigma2hat <- sigma2hat.M1 <- rep(NA, Nsim)
  rhohat.SE <- rhohat.M1.SE <- rep(NA, Nsim)
  sigma2hat.SE <- sigma2hat.M1.SE <- rep(NA, Nsim)
  
  for (i in 1:Nsim) {
    # i-th dataset (Nx(T+1))
    dati.i = dati[, , i]
    
    if (i%%100 == 0) print(i) # monitor progress

    mle <- ar.mle(dati.i)
    mu.hat <- mle$muhat
    r.hat <- mle$rhohat
    s2.hat <- mle$sigma2hat
    rhohat[i] <- r.hat
    sigma2hat[i] <- s2.hat
    
    psihat <- c(rhohat[i], sigma2hat[i])
    Jhat <- numDeriv::hessian(PLpsi, x = psihat, 
                              data = dati.i)
    se <- diag(solve(Jhat))^0.5
    rhohat.SE[i] <- se[1]
    sigma2hat.SE[i] <- se[2]
    
    ybar.0 <- apply(dati.i, 1, function(y) mean(y[1:T]))
    
    #MPL
    mle.M1 <- optimize(nloglPM1, c(-1.5, 1.5), data = dati.i, 
                       ybar0 = ybar.0, psi.hat = c(r.hat, s2.hat), 
                       mu.hat = mu.hat)
    rhohat.M1[i] <- mle.M1$minimum
    sigma2hat.M1[i] <- SS_rho(mle.M1$minimum, dati.i)/(N*(T - 1))
    
    psihatM <- c(rhohat.M1[i], sigma2hat.M1[i])
    JhatM <- numDeriv::hessian(MPLpsi, x = psihatM, data = dati.i, 
                               ybar0 = ybar.0, psihat = psihat, 
                               lambdahat = mu.hat)
    seM <- diag(solve(JhatM))^0.5
    rhohat.M1.SE[i] <- seM[1]
    sigma2hat.M1.SE[i] <- seM[2]
  }
  
  list(rhohat = rhohat, rhohat.M1 = rhohat.M1, rhohat.SE = rhohat.SE, 
       rhohat.M1.SE = rhohat.M1.SE, sigma2hat = sigma2hat, 
       sigma2hat.M1 = sigma2hat.M1, sigma2hat.SE = sigma2hat.SE, 
       sigma2hat.M1.SE = sigma2hat.M1.SE, N = attr(dati, "dim")[1], 
       T = (attr(dati, "dim")[2])-1, rho = attr(dati, "rho"), 
    sigma2 = attr(dati, "sigma2"), mu = attr(dati, "mu"), 
    t0 = dati[, 1, 1], seed = attr(dati, "seed"))
}


# simulate data with T = 10, N = 250, rho = 0.5
nsimu <- 2000

N <- 250
T <- 10

y10250 <- AR.gen.dati(rho = 0.5, sigma2 = 1, mu = rnorm(N, mean = 1, sd = 1), 
                  y0 = rep(0, N), T = T, Nsim = nsimu, seed = 321)
res10250 <- AR1simu(y10250)

# simulate data with T = 4, N = 50, rho = 0.9
nsimu <- 2000

N <- 50
T <- 4

y450 <- AR.gen.dati(rho = 0.9, sigma2 = 1, mu = rnorm(N, mean = 1, sd = 1), 
                 y0 = rep(0, N), T = T, Nsim = nsimu, seed = 321)
res450 <- AR1simu(y450)
