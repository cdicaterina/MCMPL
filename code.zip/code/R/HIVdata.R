########################## HIV DATA ################################
### treat = 0, 1
# setwd(.././R)
hiv <- read.table("dataHIV.csv", header = F)
names(hiv) <- c("y", "delta", "panelInd", "treat")
hiv$panelInd <- as.numeric(hiv$panelInd)
hiv$treat[hiv$treat == 1] <- 0
hiv$treat[hiv$treat == 2] <- 1

attach(hiv)

Xtreat <- as.matrix(treat)

library(survival)
library(numDeriv)

### reparametrization: omega = omega(psi) = omega(xi, beta) = (log xi, beta)
omega <- function(psi) {
  c(log(psi[1]), psi[-1])
}
### inverse reparametrization: psi = psi(omega)
psi.f <- function(omega) {
  c(exp(omega[1]), omega[-1])
}

# setwd(.././C)
dyn.load("MPLsurv.so")

# new panel indicator
get.g <- function(g) { 
  n <- length(g)
  out <- rep(0, n)
  uni <- unique(g)
  N <- length(unique(g))
  for(i in 1:N) {
    cond <- (g == uni[i])
    ind <- (1:n)[cond]
    out[ind] <- i
  }
  return(out)
}

# data synthesis
syn2 <- function(y, xi, panel) tapply(y^xi, panel, sum) 

### PROFILE LIK

# constr estimates of nuisance with C
lambdahat_psiC <- function(psi, y, delta, X, panel) {   
  xi <- psi[1]
  beta <- psi[-1]
  N <- length(unique(panel))   ##N.inf
  T_i <- tapply(rep(1, nrow(X)), panel, sum)   #T_i
  .C("lambda_psi",
     as.integer(sum(T_i)),
     as.integer(N),
     as.integer(T_i),
     as.integer(max(T_i)),
     as.double(xi),
     as.double(beta),
     as.integer(length(beta)),
     as.double(y),
     as.double(X),       #X nxlength(beta)
     as.integer(delta),
     lambda = as.double(rep(0.0, N)))$lambda
}

# compute l_(lambda_i, lambda_i)(theta), vector Nx1
l_ll <- function(par, lambda, y, delta, X, panel) {
  xi <- par[1]
  beta <- par[-1]
  xb <- X %*% beta # vector n x 1
  di. <- syn2(delta, xi = 1, panel = panel) # vector Nx1
  s2 <- tapply(((y^xi)*exp(-xi*xb)), panel, sum) # vector Nx1
  l <- - (xi^2) * exp(-lambda*xi) * s2        # vector Nx1   
  return(l)
}

# compute negative profile log-likelihood(psi) for random-censored data, psi = (xi, beta)
prof.lik <- function(par, y, delta, X, panel) {
  xi <- par[1]
  beta <- par[-1]
  
  if (length(beta) != ncol(X)) stop ("Wrong length of parameter psi!")
  xb <- X %*% beta # vector n x 1
  
  s1 <- sum(delta*xb) # scalar
  s2 <- tapply(((y^xi) * exp(- xi*xb)), panel, sum) # vector Nx1
  s3 <- sum(delta*log(y))  # scalar 
  
  di. <- syn2(delta, xi = 1, panel = panel) # vector Nx1
  d.. <- sum(di.) # scalar
  
  l <- d..*(log(xi) - 1) + (xi - 1)*s3 + sum(di.*log(di.)) - 
    sum(di.*log(s2)) - xi*s1
  return(-l)
}

# negative PL(omega) for random-censored data, omega=(log xi, beta)
PLomega <- function(omega, y, delta, X, panel) {
  psi <- psi.f(omega)
  prof.lik(psi, y, delta, X, panel)
}


# MPL with C, ystar and deltastar generated outside
MPLsurvC <- function(psi, y, delta, ystar, deltastar, 
                     X, panel, psihat, lambdahat) {
  xi <- psi[1]
  beta <- psi[-1]
  xihat <- psihat[1]
  betahat <- psihat[-1]
  N <- length(unique(panel))   ##N.inf
  T_i <- tapply(rep(1,nrow(X)), panel, sum)   #T_i
  R <- ncol(ystar)
  out<-.C("MPLsurvC",
          as.double(xi),
          as.double(beta),
          as.integer(length(beta)),
          as.double(X),       #X nxlength(beta)
          as.integer(N),
          as.integer(T_i),
          as.integer(sum(T_i)),
          as.integer(max(T_i)),
          as.double(y),
          as.integer(delta),
          as.double(ystar),      #matrix nxR
          as.integer(deltastar),
          as.integer(R),
          as.double(xihat),
          as.double(betahat),
          as.double(lambdahat),
          out = as.double(0.0))$out
  return(-out)
}

# MPL function of omega
MPLomega <- function(omega, y, delta, ystar, deltastar, 
                     X, panel, psihat, lambdahat) {
  psi <- psi.f(omega)
  MPLsurvC(psi, y, delta, ystar, deltastar, X, 
           panel, psihat, lambdahat)
}

#resample the censoring time (from the observed censored times) 
# for those subjects who
#had an observed failure (delta_ij=1) 
MC.condcens <- function(y, delta, Cobs, Sobs) {
  d.. <- sum(delta)
  time.int <- findInterval(y, c(0, Cobs-1e-8, Inf))
  surv <- c(1, Sobs)[time.int] #survival values at observed times
  surv[delta == 1] <- surv[delta == 1] * runif(d..)  
  #survival of new censoring times
  
  if(any(Sobs == 0)) {
    breaks <- c(sort(Sobs), 1)
    km_time <- Cobs
  } 
  else {
    breaks <- c(0, sort(Sobs), 1) 
    km_time <- c(Cobs, Inf)
  }	
  surv.int <- findInterval(surv, breaks)
  cstar <- rev(km_time)[surv.int] 
  cstar[delta==0] <- y[delta == 0]
  return(cstar) 
}	          	        

#generate right-censored samples, where failure times are from Weibull distr. with parameters
#thetahat, censoring times are generated from the empirical conditional distribution of the
#observed censoring times, given that C>T
MCrepl <- function(R, psi, lambda, y, delta, X, panel)  {
  
  xi <- psi[1]
  beta <- psi[-1]
  
  lambda.v <- as.vector(lambda)
  N <- length(lambda.v)
  
  xb <- X %*% beta
  eta <- exp(-(xb + lambda.v[panel])) #vector n x 1
  
  # Kaplan-meier survival estimate for censoring
  km <- survfit(Surv(y, delta==0) ~ 1, type = "kaplan-meier")
  Cobs <- km$time[km$n.event > 0]
  Sobs <- km$surv[km$n.event > 0]
  
  MC <- replicate(R, MCsample(xi, eta, y, delta, Cobs, Sobs)) 
  ## 2 matrices nxR
  return(MC)
}

MCsample <- function(xi, eta, y, delta, Cobs, Sobs) {
  # uncensored data from Weibull distr.
  ytildestar <- rweibull(length(eta), shape = xi, scale = 1/eta)  #nx1
  # generate cens times from conditional distr.
  cstar <- MC.condcens(y, delta, Cobs, Sobs) # nx1
  # Observe the minimum between the two times 
  ystar <- pmin(ytildestar, cstar)
  deltastar <- as.numeric(cstar > ytildestar)
  return(list(ystar = ystar, deltastar = deltastar) )
}

###################################################
###################################################

delta1 <- hiv$delta
y1 <- hiv$y

n <- nrow(Xtreat)                        
N <- length(unique(panelInd))                
T <- tapply(rep(1, n), panelInd, sum)  
ncov <- ncol(Xtreat)                           

di. <- syn2(delta1, 1, panelInd) 
Ncens <- length(delta1)-sum(delta1)  

## remove noninformative strata with all censored obs.
cond <- !(di. == 0)
ind <- match(panelInd, names(cond))
sele <- cond[ind]

y.i <- y1[sele]
X.i <- as.matrix(Xtreat[sele, ])
n1 <- nrow(X.i)
delta.i <- delta1[sele]
Ninf <- sum(cond)

### MLE
panel.i <- get.g(panelInd[sele])
mleHIV <- optim(rep(0, 2), PLomega, y = y.i, delta = delta.i, 
                X = X.i, panel = panel.i, hessian = TRUE)
mleHIV

mle.SE <- diag(solve(numDeriv::hessian(prof.lik, x = psi.f(mleHIV$par), 
                             X = X.i, y = y.i, delta = delta.i, 
                             panel = panel.i)))^.5
mle.SE


psihat <- c(exp(mleHIV$par[1]), mleHIV$par[2])
lambdahat <- lambdahat_psiC(psihat, y = y.i, delta = delta.i, 
                            X = X.i, panel = panel.i)

# generate R Monte Carlo simulated data
R <- 500
set.seed(345)
MC <- MCrepl(R = R, psi = psihat, lambda = lambdahat, y = y.i, 
             delta = delta.i, X = X.i, panel = panel.i)
ystar.i <- matrix(unlist(MC["ystar", ]), nrow = nrow(X.i), 
                  ncol = R, byrow = F)
deltastar.i <- matrix(unlist(MC["deltastar", ]), nrow = nrow(X.i), 
                      ncol = R, byrow = F)

### MCMPL
MPL.HIV <- optim(mleHIV$par, MPLomega, y = y.i, delta = delta.i, 
                 ystar = ystar.i, deltastar = deltastar.i, X = X.i, 
                 panel = panel.i, psihat = psihat, lambdahat = lambdahat)
MPL.HIV$par

## profile log-lik for beta ##
profBeta <- function(beta, y, delta, X, panel) {
  nlminb(0, function(lxi) PLomega(omega = c(lxi, beta), y = y, 
                                  delta = delta, X = X, panel = panel))$objective
}

prof.H0b <- profBeta(0, y = y.i, delta = delta.i, X = X.i, 
                     panel = panel.i)

#### H0: beta1 = 0 (no treat effect) ####
W.prof0b <- 2*(prof.H0b-mleHIV$value)
W.prof0b

pval.prof0b <- 1-pchisq(W.prof0b, df = 1)
pval.prof0b

## MCMPL for beta ##
MPL.Beta <- function(beta, y, delta, ystar, deltastar, X, 
                     panel, psihat, lambdahat) {
  nlminb(0, function(lxi) MPLomega(omega = c(lxi, beta), 
                                   y = y.i, delta = delta.i, ystar = ystar.i, 
    deltastar = deltastar.i, X = X.i, panel = panel.i, psihat = psihat, 
    lambdahat = lambdahat))$objective
}

MPL.H0b <- MPL.Beta(0, y = y.i, delta = delta.i, ystar = ystar.i, 
                    deltastar = deltastar.i, X = X.i, 
  psihat = psihat, lambdahat = lambdahat, panel = panel.i)

W.MPL0b <- 2*(MPL.H0b - MPL.HIV$value)
W.MPL0b

pval.MPL0b <- 1 - pchisq(W.MPL0b, df = 1)
pval.MPL0b

#### H0: xi = 1 (exponential survival times) ####
## profile log-lik for xi ##
profXi <- function(xi, y, delta, X, panel) {
  nlminb(0, function(beta) prof.lik(par = c(xi, beta), y = y, 
                    delta = delta, X = X, panel = panel))$objective
}

prof.H0xi <- profXi(1, y = y.i, delta = delta.i, X = X.i, 
                    panel = panel.i)

W.prof0xi <- 2*(prof.H0xi - mleHIV$value)
W.prof0xi

pval.prof0xi <- 1 - pchisq(W.prof0xi, df = 1)
pval.prof0xi

## profile log-lik for log(xi) ##
proflXi <- function(lxi, y, delta, X, panel) {
  nlminb(0, function(beta) PLomega(omega = c(lxi, beta), y = y, 
                    delta = delta, X = X, panel = panel))$objective
}

prof.H0lxi <- proflXi(0, y = y.i, delta = delta.i, X = X.i, 
                      panel = panel.i)

W.prof0lxi <- 2 * (prof.H0lxi - mleHIV$value)
W.prof0lxi

pval.prof0lxi <- 1 - pchisq(W.prof0lxi, df = 1)
pval.prof0lxi

## MCMPL for xi ##
MPL.Xi <- function(xi, y, delta, ystar, deltastar, X, panel, 
                   psihat, lambdahat) {
  nlminb(0, function(beta) MPLsurvC(psi = c(xi, beta), y = y.i, 
                                    delta = delta.i, ystar = ystar.i, 
    deltastar = deltastar.i, X = X.i, panel = panel.i, psihat = psihat, 
    lambdahat = lambdahat))$objective
}

MPL.H0xi <- MPL.Xi(1, y = y.i, delta = delta.i, ystar = ystar.i, 
                   deltastar = deltastar.i, X = X.i, 
  psihat = psihat, lambdahat = lambdahat, panel = panel.i)

W.MPL0xi <- 2 * (MPL.H0xi - MPL.HIV$value)
W.MPL0xi

pval.MPL0xi <- 1 - pchisq(W.MPL0xi, df = 1)
pval.MPL0xi

## MCMPL for log(xi) ##
MPL.lXi <- function(lxi, y, delta, ystar, deltastar, X, 
                    panel, psihat, lambdahat) {
  nlminb(0, function(beta) MPLomega(omega = c(lxi, beta), y = y.i, 
                                    delta = delta.i, ystar = ystar.i, 
    deltastar = deltastar.i, X = X.i, panel = panel.i, psihat = psihat, 
    lambdahat = lambdahat))$objective
}

MPL.H0lxi <- MPL.lXi(0, y = y.i, delta = delta.i, ystar = ystar.i, 
                     deltastar = deltastar.i, X = X.i, 
  psihat = psihat, lambdahat = lambdahat, panel = panel.i)

W.MPL0lxi <- 2*(MPL.H0lxi - MPL.HIV$value)
W.MPL0lxi

pval.MPL0lxi <- 1-pchisq(W.MPL0lxi, df = 1)
pval.MPL0lxi

#### H0: xi = 1, beta = 0 (exponential+no treat effect) ####
prof.H0xib <- prof.lik(par = c(1, 0), y = y.i, delta = delta.i, 
                       X = X.i, panel = panel.i)

W.prof0xib <- 2*(prof.H0xib-mleHIV$value)
W.prof0xib

pval.prof0xib <- 1 - pchisq(W.prof0xib, df = 1)
pval.prof0xib

MPL.H0xib <- MPLsurvC(psi = c(1, 0), y = y.i, delta = delta.i, 
                      ystar = ystar.i, deltastar = deltastar.i, 
  X = X.i, psihat = psihat, lambdahat = lambdahat, panel = panel.i)

W.MPL0xib <- 2*(MPL.H0xib - MPL.HIV$value)
W.MPL0xib

pval.MPL0xib <- 1 - pchisq(W.MPL0xib, df = 1)
pval.MPL0xib

#### H0: log(xi) = 0, beta = 0 (exponential+no treat effect) ####
prof.H0lxib <- PLomega(omega = c(0, 0), y = y.i, delta = delta.i, 
                       X = X.i, panel = panel.i)

W.prof0lxib <- 2*(prof.H0lxib - mleHIV$value)
W.prof0lxib

pval.prof0lxib <- 1 - pchisq(W.prof0lxib, df = 1)
pval.prof0lxib

MPL.H0lxib <- MPLomega(omega = c(0, 0), y = y.i, delta = delta.i, 
                       ystar = ystar.i, deltastar = deltastar.i, 
  X = X.i, psihat = psihat, lambdahat = lambdahat, panel = panel.i)

W.MPL0lxib <- 2*(MPL.H0lxib - MPL.HIV$value)
W.MPL0lxib

pval.MPL0lxib <- 1 - pchisq(W.MPL0lxib, df = 1)
pval.MPL0lxib

###### CI 0.95 #######
conf.level <- 0.95
#### xi ####
## profile ##
ci.xi <- uniroot(function(x) -profXi(x, y = y.i, delta = delta.i, 
                                     X = X.i, panel = panel.i) + 
    profXi(psihat[1], y = y.i, delta = delta.i, X = X.i, panel = panel.i) + 
    qchisq(conf.level, 1)/2, c(1e-10, psihat[1]))$root
ci.xi <- c(ci.xi, uniroot(function(x) -profXi(x, y = y.i, 
                              delta = delta.i, X = X.i, panel = panel.i) + 
    profXi(psihat[1], y = y.i, delta = delta.i, X = X.i, panel = panel.i) + 
    qchisq(conf.level, 1)/2, c(psihat[1], 10))$root)
ci.xi

## MPL ##
ciMPL.xi <- uniroot(function(x) -MPL.Xi(x, y = y.i, delta = delta.i, 
                                        ystar = ystar.i, 
  deltastar = deltastar.i, X = X.i, psihat = psihat, lambdahat = lambdahat, 
  panel = panel.i) + MPL.Xi(exp(MPL.HIV$par[1]), y = y.i, delta = delta.i, 
                            ystar = ystar.i, 
    deltastar = deltastar.i, X = X.i, psihat = psihat, lambdahat = lambdahat, 
    panel = panel.i) + qchisq(conf.level, 1)/2, c(1e-10, exp(MPL.HIV$par[1])))$root
ciMPL.xi <- c(ciMPL.xi, uniroot(function(x) -MPL.Xi(x, y = y.i, delta = delta.i, 
                                                    ystar = ystar.i, 
  deltastar = deltastar.i, X = X.i, psihat = psihat, lambdahat = lambdahat, panel = panel.i) + 
    MPL.Xi(exp(MPL.HIV$par[1]), y = y.i, delta = delta.i, ystar = ystar.i, 
           deltastar = deltastar.i, 
      X = X.i, psihat = psihat, lambdahat = lambdahat, panel = panel.i) + 
    qchisq(conf.level, 1)/2, c(exp(MPL.HIV$par[1]), 10))$root)
ciMPL.xi

#### log(xi) ####
## prof ##
ci.lxi <- uniroot(function(x) -proflXi(x, y = y.i, delta = delta.i, 
                                       X = X.i, panel = panel.i) + 
    proflXi(log(psihat[1]), y = y.i, delta = delta.i, X = X.i, panel = panel.i) + 
    qchisq(conf.level, 1)/2, c(-10, log(psihat[1])))$root
ci.lxi <- c(ci.lxi, uniroot(function(x) -proflXi(x, y = y.i, delta = delta.i, 
                                                 X = X.i, panel = panel.i) + 
    proflXi(log(psihat[1]), y = y.i, delta = delta.i, X = X.i, panel = panel.i) + 
    qchisq(conf.level, 1)/2, c(log(psihat[1]), 10))$root)
ci.lxi

exp(ci.lxi)

## MPL ##
ciMPL.lxi <- uniroot(function(x) -MPL.lXi(x, y = y.i, delta = delta.i, 
                                          ystar = ystar.i, 
  deltastar = deltastar.i, X = X.i, psihat = psihat, lambdahat = lambdahat, 
  panel = panel.i) + MPL.lXi(MPL.HIV$par[1], y = y.i, delta = delta.i, 
                             ystar = ystar.i, 
    deltastar = deltastar.i, X = X.i, psihat = psihat, lambdahat = lambdahat, 
    panel = panel.i) + qchisq(conf.level, 1)/2, c(-5, MPL.HIV$par[1]))$root
ciMPL.lxi <- c(ciMPL.lxi, uniroot(function(x) -MPL.lXi(x, y = y.i, 
                                            delta = delta.i, ystar = ystar.i, 
  deltastar = deltastar.i, X = X.i, psihat = psihat, lambdahat = lambdahat, 
                    panel = panel.i) + 
    MPL.lXi(MPL.HIV$par[1], y = y.i, delta = delta.i, ystar = ystar.i, 
            deltastar = deltastar.i, 
      X = X.i, psihat = psihat, lambdahat = lambdahat, panel = panel.i) + 
    qchisq(conf.level, 1)/2, c(MPL.HIV$par[1], 2))$root)
ciMPL.lxi

exp(ciMPL.lxi)

#### beta ####
## prof ##
ci.beta <- uniroot(function(x) -profBeta(x, y = y.i, delta = delta.i, 
                                         X = X.i, panel = panel.i) + 
    profBeta(psihat[2], y = y.i, delta = delta.i, X = X.i, panel = panel.i) + 
    qchisq(conf.level, 1)/2, c(-10, psihat[2]))$root
ci.beta <- c(ci.beta, uniroot(function(x) -profBeta(x, y = y.i, 
                                            delta = delta.i, X = X.i, 
  panel = panel.i) + profBeta(psihat[2], y = y.i, delta = delta.i, 
                              X = X.i, panel = panel.i) 
  + qchisq(conf.level, 1)/2, c(psihat[2], 10))$root)
ci.beta

## MPL ##
ciMPL.beta <- uniroot(function(x) -MPL.Beta(x, y = y.i, 
                                            delta = delta.i, ystar = ystar.i, 
  deltastar = deltastar.i, X = X.i, psihat = psihat, lambdahat = lambdahat, 
  panel = panel.i) + MPL.Beta(MPL.HIV$par[2], y = y.i, 
                              delta = delta.i, ystar = ystar.i, 
    deltastar = deltastar.i, X = X.i, psihat = psihat, lambdahat = lambdahat, 
    panel = panel.i) + qchisq(conf.level, 1)/2, c(-10, MPL.HIV$par[2]))$root
ciMPL.beta <- c(ciMPL.beta, uniroot(function(x) -MPL.Beta(x, y = y.i, 
                                            delta = delta.i, ystar = ystar.i, 
  deltastar = deltastar.i, X = X.i, psihat = psihat, 
  lambdahat = lambdahat, panel = panel.i)
  + MPL.Beta(MPL.HIV$par[2], y = y.i, delta = delta.i, ystar = ystar.i, 
    deltastar = deltastar.i, X = X.i, psihat = psihat, lambdahat = lambdahat, 
    panel = panel.i)
  + qchisq(conf.level, 1)/2, c(MPL.HIV$par[2], 10))$root)
ciMPL.beta

## stratified Cox PH model
gee_surv <- coxph(Surv(y, delta) ~ treat + strata(panelInd), data = hiv)
summary(gee_surv)

rrhat <- summary(gee_surv)$coefficients[2]
rrhat

sehat <- sqrt(summary(gee_surv)$coefficients[2] *
                summary(gee_surv)$coefficients[3])
sehat

ci <- exp(summary(gee_surv)$coefficients[1] + c(-1, 1) * 
            qnorm(0.975)* summary(gee_surv)$coefficients[3])
ci

### Figure 1 ###
library("ggplot2")
require("plyr")
require("dplyr")
library("extrafont")
#font_install('fontcm')

par <- c("xi", "beta")
x.xi <- seq(0.4, 2.1, length = 100)
x.beta <- seq(-4, 1, length = 100)


col1 <- c(rep("xi", 200), rep("beta", 200))
col2 <- rep(c(rep("pl", 100), rep("mpl", 100)), 2)
col3 <- c(rep(x.xi, 2), rep(x.beta, 2))

df <- cbind(col1, col2, col3)

df <- data.frame(par = col1, method = col2, z = col3)


pl.xi <- sapply(x.xi, function(x.xi) mleHIV$value - profXi(x.xi, y = y.i, 
                                  delta = delta.i, X = X.i, panel = panel.i))
mpl.xi <- sapply(x.xi, function(x.xi) - MPL.Xi(x.xi, y = y.i, delta = delta.i, 
                                               ystar = ystar.i, 
  deltastar = deltastar.i, X = X.i, psihat = psihat, lambdahat = lambdahat, 
  panel = panel.i)) + MPL.HIV$value

pl.beta <- sapply(x.beta, function(x.beta) mleHIV$value - profBeta(x.beta, y = y.i, 
                                          delta = delta.i, X = X.i, panel = panel.i))
mpl.beta <- sapply(x.beta, function(x.beta) - MPL.Beta(x.beta, y = y.i, 
                                                       delta = delta.i, ystar = ystar.i, 
  deltastar = deltastar.i, X = X.i, psihat = psihat, lambdahat = lambdahat, panel = panel.i)) +
  MPL.HIV$value

loglik <- c(pl.xi, mpl.xi, pl.beta, mpl.beta)

df <- data.frame(df, loglik = loglik)


df$setting <- paste0("setting", seq_len(nrow(df)))

df$method <- factor(df$method, levels= c("pl", "mpl"), 
                    ordered = TRUE)
df$parstring <- factor(df$par, levels= c("xi", "beta"), 
                       labels = c("xi", "beta"), ordered = TRUE)

df$loglik[is.infinite(df$loglik) | is.na(df$loglik)] <- NA

data.segm1PLxi <- data.frame(x = ci.xi[1], y = -10, xend = ci.xi[1], 
                             yend = mleHIV$value-profXi(ci.xi[1], y = y.i, 
  delta = delta.i, X = X.i, panel = panel.i), parstring = "xi")
data.segm2PLxi <- data.frame(x = ci.xi[2], y = -10, xend = ci.xi[2], 
                             yend = mleHIV$value-profXi(ci.xi[2], y = y.i, 
  delta = delta.i, X = X.i, panel = panel.i), parstring = "xi")

data.segm1PLbeta <- data.frame(x = ci.beta[1], y = -10, xend = ci.beta[1], 
                               yend = mleHIV$value-profBeta(ci.beta[1], y = y.i, 
  delta = delta.i, X = X.i, panel = panel.i), parstring = "beta")
data.segm2PLbeta <- data.frame(x = ci.beta[2], y = -10, xend = ci.beta[2], 
                               yend = mleHIV$value-profBeta(ci.beta[2], y = y.i, 
  delta = delta.i, X = X.i, panel = panel.i), parstring = "beta")

data.segm1MPLxi <- data.frame(x = ciMPL.xi[1], y = -10, xend = ciMPL.xi[1], 
                              yend = MPL.HIV$value-MPL.Xi(ciMPL.xi[1], y = y.i, 
                                        delta = delta.i, ystar = ystar.i, 
  deltastar = deltastar.i, X = X.i, psihat = psihat, lambdahat = lambdahat, 
  panel = panel.i), parstring = "xi")
data.segm2MPLxi <- data.frame(x = ciMPL.xi[2], y = -10, xend = ciMPL.xi[2], 
                              yend = MPL.HIV$value-MPL.Xi(ciMPL.xi[1], y = y.i, 
                                          delta = delta.i, ystar = ystar.i, 
  deltastar = deltastar.i, X = X.i, psihat = psihat, lambdahat = lambdahat, 
  panel = panel.i), parstring = "xi")

data.segm1MPLbeta <- data.frame(x = ciMPL.beta[1], y = -10, xend = ciMPL.beta[1], 
              yend = MPL.HIV$value-MPL.Beta(ciMPL.beta[1], y = y.i, delta = delta.i, 
  ystar = ystar.i, deltastar = deltastar.i, X = X.i, psihat = psihat, 
  lambdahat = lambdahat, panel = panel.i), parstring = "beta")
data.segm2MPLbeta <- data.frame(x = ciMPL.beta[2], y = -10, xend = ciMPL.beta[2], 
            yend = MPL.HIV$value-MPL.Beta(ciMPL.beta[2], y = y.i, delta = delta.i, 
  ystar = ystar.i, deltastar = deltastar.i, X = X.i, psihat = psihat, 
  lambdahat = lambdahat, panel = panel.i), parstring = "beta")

plot_hiv <- ggplot(df, aes(z, loglik, group= method, col= method, lty= method)) +
  geom_hline(aes(yintercept= -qchisq(0.95, 1)/2), color= 1, alpha= 0.25) +
  geom_line(alpha = 0.5) +
  geom_segment(data = data.segm1PLxi, aes(x = x, y = y, yend = yend, xend = xend), 
               inherit.aes = FALSE, col = 6, alpha= 0.35, lty = "dotted") +
  geom_segment(data = data.segm2PLxi, aes(x = x, y = y, yend = yend, xend = xend), 
               inherit.aes = FALSE, col = 6, alpha= 0.35, lty = "dotted") +
  geom_segment(data = data.segm1PLbeta, aes(x = x, y = y, yend = yend, xend = xend), 
               inherit.aes = FALSE, col = 6, alpha= 0.35, lty = "dotted") +
  geom_segment(data = data.segm2PLbeta, aes(x = x, y = y, yend = yend, xend = xend), 
               inherit.aes = FALSE, col = 6, alpha= 0.35, lty = "dotted") +
  geom_segment(data = data.segm1MPLxi, aes(x = x, y = y, yend = yend, xend = xend), 
               inherit.aes = FALSE, col = 4, alpha= 0.35, lty = "dotted") +
  geom_segment(data = data.segm2MPLxi, aes(x = x, y = y, yend = yend, xend = xend), 
               inherit.aes = FALSE, col = 4, alpha= 0.35, lty = "dotted") +
  geom_segment(data = data.segm1MPLbeta, aes(x = x, y = y, yend = yend, xend = xend), 
               inherit.aes = FALSE, col = 4, alpha= 0.35, lty = "dotted") +
  geom_segment(data = data.segm2MPLbeta, aes(x = x, y = y, yend = yend, xend = xend), 
               inherit.aes = FALSE, col = 4, alpha= 0.35, lty = "dotted") +
  facet_wrap( ~ parstring, scales = "free", labeller= label_parsed) +
  coord_cartesian(ylim= c(-4, 0)) +
  labs(y= "Relative log-likelihood", x =  " ") +
  theme_bw() +
  theme(text = element_text(size = 12, family = "CM Roman")) +
  theme(legend.position = "none", panel.grid.major.y = element_blank(), 
        panel.grid.minor.y = element_blank(), 
    panel.grid.minor.x = element_blank(), panel.grid.major.x = element_blank(), 
    strip.background = element_blank()) +
  scale_linetype_manual(name = "", values = c(2, 1), 
    labels = c(expression(italic(l)[italic(P)]), expression(italic(l)[italic(M)^list("*")]))) +
  scale_colour_manual(name = "", values= c(6, 4), labels = c(expression(italic(l)[italic(P)]), 
                                              expression(italic(l)[italic(M)^list("*")])))


# pdf("ggHIVcoldash.pdf", width= 7, height= 7/sqrt(2))
# print(plot_hiv)
# dev.off()
# embed_fonts("ggHIVcoldash.pdf", outfile = "ggHIVcoldash.pdf")
# system("pdf2ps ggHIVcoldash.pdf ggHIVcoldash.eps")
# save(df, file= "ggdfHIV.RData")



