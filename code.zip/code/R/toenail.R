############# Toenail infection study #############
# setwd(.././R)
load("toenail.Rdata")

# create dataset with missing values
N <- length(unique(Toenail$ID))
T <- 7

panel <- Toenail$ID
month <- Toenail$Imonth
treat <- Toenail$Treatment
y <- Toenail$Response


# complete panel vector (with NA on y)
panelInd <- rep(1:N, each = T)
# complete month vector (with NA on y)
monthNA <- rep(c(0, 1, 2, 3, 6, 9, 12), times = N)


# get indexes of missing data
index <- 0
check <- TRUE
i <- 0
for (j in 1:(N*T)) {
  if (check == TRUE) i <- i + 1
  if (i > length(month)) i <- i - 1
  check <- (month[i] == monthNA[j])
  if (check == FALSE) index <- c(index, j)
}
index <- index[-1]
# 150 missing data
length(index)

# y vector with NA
yNA <- rep(NA, N*T)
yNA[-index] <- y
yNA

# treat vector with NA
tr <- rep(NA, N)
for (i in 1:N) tr[i] <- treat[Toenail$ID == unique(Toenail$ID)[i]][1]
treatNA <- rep(tr, each = T)

# % missing data = 7.29
sum(is.na(yNA))/length(yNA)

# 115 informative strata
ybar <- tapply(yNA, panelInd, mean, na.rm = TRUE)
sum((ybar != 1) & (ybar != 0))

# MPL fit via panelMPL new
#setwd("./../C")
dyn.load("MPLlogitMCAR.so")
dyn.load("MPLlogitMNAR.so")

######################
#setwd("./../R")
# source("main.R")
# source("utils.R")
# source("dynBinary.R")
# source("misBinary.R")

# remove uninfo strata for PL fit
M <- as.vector(ifelse(is.na(yNA), 1, 0))
mean.y <- tapply(yNA, panelInd, mean, na.rm = TRUE)
cond <- !((mean.y == 0) | (mean.y == 1) | (is.nan(mean.y) == 1))
ind <- match(panelInd, names(cond)) 
sele <- cond[ind]
Mr <- M[sele]
yr <- yNA[sele]
xe <- cbind(monthNA, treatNA*monthNA)
xr <- as.matrix(xe[sele, ])
nr <- ncol(xr)
panelr <- panelInd[sele]
panelG <- get.g(panelr)

noMisData <- cbind(xr, yr, panelG, Mr)
noMisData <- noMisData[Mr == 0,]
noMDy <- noMisData[, nr + 1]
noMDx <- as.matrix(noMisData[, 1:nr])
noMDpanel <- noMisData[, nr + 2]

NA0y <- ifelse (Mr == 1, rep(0, length(yr)), yr)

### negative MCAR profile log-likelihood
MdLogitPL <- function(beta, noMDy, noMDx, noMDpanel)  { 
  alpha <- dynLogitAlpha(noMDx, noMDpanel, noMDy, 
                         beta, rep(0, length(unique(noMDpanel)))) 
  eta <- noMDx %*% beta + alpha[noMDpanel]
  p <- p.range(plogis(eta))
  out <- sum(noMDy*log(p) + (1 - noMDy)*log(1 - p))
  return(-out)
}

### negative Severini's MPL -- no I term
unbMdLogitMPLnoI <- function(beta, noMDx, noMDy,
                             noMDpanel) {   
  q <- length(unique(noMDpanel))  
  ng <- tapply(rep(1, nrow(noMDx)), noMDpanel, sum)   
  out <-.C("stat_logit_MPL",
           as.double(beta),
           as.integer(length(beta)),
           as.double(noMDx),   
           as.integer(nrow(noMDx)),    
           as.double(noMDy),
           as.integer(ng),     
           as.integer(q),     
           as.integer(max(ng)),
           out = as.double(0.0))$out
  return(-out)
}

### negative MCAR MCMPL
unbMdLogitMPLS4 <-  function(beta, noMDx, X, noMDy, noMDpanel, 
                             panel, R = 500, seed = 321, beta.mle,
                             alpha.mle, p.logit.hat) {   
  set.seed(seed)
  q <- length(unique(noMDpanel))  
  ng <- tapply(rep(1, nrow(noMDx)), noMDpanel, sum)   
  m <- tapply(rep(1, nrow(X)), panel, sum)  
  out <-.C("unb_logitMD_MPL_simu4",
           as.double(beta),
           as.integer(length(beta)),
           as.double(noMDx),  
           as.double(X),       
           as.integer(nrow(noMDx)),   
           as.integer(m),
           as.integer(sum(m)),
           as.integer(max(m)),
           as.double(noMDy),
           as.integer(ng),    
           as.integer(q),      
           as.integer(max(ng)),
           as.integer(R),
           as.double(beta.mle),
           as.double(alpha.mle),
           as.double(p.logit.hat),
           out = as.double(0.0))$out
  return(-out)
}

### observed negative MNAR profile log-likelihood, theta = (beta,gamma)
NIlogitPL_noG1 <- function(theta, Xe, y_noNA, M, panel) { 
  beta <- theta[1:ncol(Xe)]
  gamma <- c(0, theta[-(1:ncol(Xe))])
  alpha <- NIlogitAlpha_noG1(Xe, panel, y_noNA, M, theta, 
                             rep(0, length(unique(panel))))
  eta <- Xe %*% beta + alpha[panel]
  omega <- Xe %*% gamma[- c(1, length(gamma))] + rep(gamma[1], nrow(Xe)) + 
    gamma[length(gamma)]*y_noNA*(1-M)
  omegaM <- Xe %*% gamma[- c(1, length(gamma))] + rep(gamma[1], nrow(Xe)) + 
    gamma[length(gamma)]
  mu <- p.range(plogis(eta))
  p <- p.range(plogis(omega))
  pM <- p.range(plogis(omegaM))
  out <- sum((1 - M)*(y_noNA*log(mu) + (1 - y_noNA) * log(1 - mu) + log(1 - p)) +
               M*log((1 - mu)*p + mu*pM))
  return(-out)
} 

### constrained estimates of lambda under MNAR model
NIlogitAlpha_noG1 <- function(Xe, panel, y_noNA, M, theta, alpha.in) {   
  beta <- theta[1:ncol(Xe)]
  gamma <- c(0, theta[-(1:ncol(Xe))])
  q <- length(unique(panel)) 
  ng <- tapply(rep(1, nrow(Xe)), panel, sum) 
  .C("NI_logit_alpha",
     as.double(alpha.in),
     as.double(beta),
     as.double(Xe),
     as.integer(length(beta)),
     as.double(gamma),
     as.integer(length(gamma)),
     as.double(y_noNA),
     as.integer(M),
     as.integer(nrow(Xe)),
     as.integer(ng),
     as.integer(q),
     as.integer(max(ng)),
     as.double(10^-6),
     as.integer(100),
     alpha = as.double(rep(0.0,q)))$alpha
}

### negative MNAR MCMPL
unbNIlogitMPLS_noG1 <- function(theta, X, y_noNA, M, 
                                panel, R = 500, seed = 321, theta.mle, alpha.mle) {   
  set.seed(seed)
  beta <- theta[1:ncol(X)]
  gamma <- c(0,theta[-(1:ncol(X))])
  betahat <- theta.mle[1:ncol(X)]
  gammahat <- c(0, theta.mle[-(1:ncol(X))])
  q <- length(unique(panel))   
  m <- tapply(rep(1, nrow(X)), panel, sum)   
  out <- .C("unb_logitNI_MPL_simu",
            as.double(beta),
            as.integer(length(beta)),
            as.double(gamma),
            as.integer(length(gamma)),
            as.double(X),      
            as.integer(q),
            as.integer(m),
            as.integer(sum(m)),
            as.integer(max(m)),
            as.double(y_noNA),
            as.integer(M),
            as.integer(R),
            as.double(betahat),
            as.double(alpha.mle),
            as.double(gammahat),
            out = as.double(0.0))$out
  return(-out)
}

# fit
# MCAR PL
fitMCARpl <- nlminb(rep(0, 2), MdLogitPL, noMDy = noMDy, 
                    noMDx = noMDx, noMDpanel = noMDpanel)
MLest <- fitMCARpl$par
MLest
round(MLest, digits = 3)

hessMCARpl <- numDeriv::hessian(MdLogitPL, x = MLest, noMDy = noMDy, 
                      noMDx = noMDx, noMDpanel = noMDpanel)

seMCARpl <- sqrt(diag(solve(hessMCARpl)))
round(seMCARpl, digits = 3)

tMCARpl <- fitMCARpl$par/seMCARpl
tMCARpl
pMCARpl <- 2*pnorm(-abs(tMCARpl))
round(pMCARpl, digits = 3)
# only time significant

# MCAR Severini's MPL
fitMCARmpl <- nlminb(MLest, unbMdLogitMPLnoI, noMDx = noMDx, 
                  noMDy = noMDy, noMDpanel = noMDpanel)
MPLest <- fitMCARmpl$par
MPLest
round(MPLest, digits = 3)

hessMCARmpl <- numDeriv::hessian(unbMdLogitMPLnoI, x = MPLest, noMDy = noMDy, 
                                noMDx = noMDx, noMDpanel = noMDpanel)

seMCARmpl <- sqrt(diag(solve(hessMCARmpl)))
round(seMCARmpl, digits = 3)

tMCARmpl <- fitMCARmpl$par/seMCARmpl
tMCARmpl
pMCARmpl <- 2*pnorm(-abs(tMCARmpl))
round(pMCARmpl, digits = 3)
# only time significant

# MNAR
# PL
fitMNARpl <- nlminb(rep(0, 5), NIlogitPL_noG1, Xe = xr, 
                    y_noNA = NA0y, M = Mr, panel = panelG)
MLestMNAR <- fitMNARpl$par
MLestMNAR
round(MLestMNAR[1:2], digits = 3)

hessMNARpl <- numDeriv::hessian(NIlogitPL_noG1, x = MLestMNAR, 
                      Xe = xr, y_noNA = NA0y, M = Mr, panel = panelG)
seMNARpl <- sqrt(diag(solve(hessMNARpl)))
round(seMNARpl[1:2], digits = 3)

tMNARpl <- fitMNARpl$par/seMNARpl
tMNARpl
pMNARpl <- 2*pnorm(-abs(tMNARpl))
round(pMNARpl[1:2], digits = 3)
# both time and interaction significant

# MNAR MCMPL
lambdahat <- NIlogitAlpha_noG1(xr, panelG, NA0y, Mr, MLestMNAR,
                              rep(0, length(unique(panelG))))
fitMNARmpl <- nlminb(MLestMNAR, unbNIlogitMPLS_noG1, y_noNA = NA0y, 
                  X = xr, panel = panelG, M = Mr, 
                  theta.mle = MLestMNAR, alpha.mle = lambdahat)
MPLestMNAR <- fitMNARmpl$par
MPLestMNAR
round(MPLestMNAR[1:2], digits = 3)

hessMNARmpl <- numDeriv::hessian(unbNIlogitMPLS_noG1, x = MPLestMNAR, 
                                X = xr, y_noNA = NA0y, M = Mr, panel = panelG, 
                                theta.mle = MLestMNAR, alpha.mle = lambdahat)
seMNARmpl <- sqrt(diag(solve(hessMNARmpl)))
round(seMNARmpl[1:2], digits = 3)

tMNARmpl <- fitMNARmpl$par/seMNARmpl
tMNARmpl
pMNARmpl <- 2*pnorm(-abs(tMNARmpl))
round(pMNARmpl[1:2], digits = 3)
