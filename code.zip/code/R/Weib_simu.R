#####################    SIMULATIONS    ########################
#####################   Weibull model    ########################
library(survival)
library(numDeriv)

# new panel indicator
get.g <- function(g) { 
  n <- length(g)
  out <- rep(0,n)
  uni <- unique(g)
  N <- length(unique(g))
  for (i in 1:N) {
    cond <- (g == uni[i])
    ind <- (1:n)[cond]
    out[ind] <- i
  }
  return(out)
}

### reparametrization: omega=omega(psi) = omega(xi, beta) = (log xi, beta)
omega <- function(psi) {
  c(log(psi[1]), psi[-1])
}
### inverse reparametrization: psi = psi(omega)
psi.f <- function(omega) {
  c(exp(omega[1]), omega[-1])
}

# setwd(.././C)
dyn.load("MPLsurv.so")

# Find values for common varsigma, given parameters (lambda_i, psi) and given probability of 
# censoring P_c
# X matrix of covariates n x (k0-1) 
# beta vector px1
varsigma.cens <-function(psi, lambda, X, panel, prob.cens){
  n <- nrow(X)                
  N <- length(unique(panel))  
  T_i <- tapply(rep(1, nrow(X)), panel, sum)   
  
  lambda.v <- as.vector(lambda)
  xi <- psi[1]
  beta <- psi[-1]
  xb <- X %*% beta
  eta <- exp(-(xb + lambda.v[panel]))
  
  lower <- 0.0001
  upper <- 1000
  # "fun" for function to be solved in uniroot, other letters for computing probabilities of
  # censoring for each stratum
  f1 <-function(varsigma, option = "fun") {
    prob <- rep(0, n)
    for (i in 1:n) {
      int <- function(t) {
        varsigma*exp(- varsigma*t) * exp(-(eta[i]*t)^xi)
      }	                      
      prob[i] <- integrate(int, 0, Inf)$value     #vector of dim=sum(T_i)
    }
    if (option == "fun") {
      sol = mean(prob) - prob.cens
    }
    else { 
      sol <- prob
    }
    return(sol)
  }
  
  varsigma <- uniroot(f1, c(lower,upper))$root
  prob <- f1(varsigma, option="a")
  prob.str <- tapply(prob, panel, mean)
  return(list(varsigma = varsigma, mean.prob = mean(prob), 
              prob.ij = prob, prob.str = prob.str))
}

#simulate Nsim right-censored samples: failure times y_ij are Weibull distr. with shape xi
#and scales eta_ij, censoring times are from Exp. distr. with parameters varsigma_1,...,varsigma_n
#or with common parameter varsigma

### 1 DATASET SIMULATION in VECTOR form - LIST
simu_weib <- function(X, panel, psi, lambda, varsigma) {
  n <- nrow(X)                
  N <- length(unique(panel))  
  T_i <- tapply(rep(1,n), panel, sum)   
  
  # varsigma tunes the censoring times' distribution and the cluster-specific intercepts
  varsigma.v <- as.vector(varsigma)
  if((length(varsigma.v) != 1) & (length(varsigma.v) != N)) stop ("Wrong length of varsigma!")
  
  if(is.null(lambda)) lambda <- rnorm(N, mean = varsigma.v, 
                                      sd = sqrt(0.045))
  lambda.v <- as.vector(lambda)
  
  xi <- psi[1]
  beta <- psi[-1]
  
  if(length(beta) != ncol(X)) stop("Wrong length of beta!")
  if(length(lambda.v) != N) stop("Wrong length of lambda!")
  
  xb <- X %*% beta
  eta <- exp(-(xb + lambda.v[panel])) 
  ytilde <- rweibull(n, shape = xi, scale = 1/eta)
  
  if (length(varsigma.v) == 1) {
    censtimes <- rexp(n, rate = rep(varsigma.v, n))
  }
  else {
    censtimes <- rexp(n, rate = varsigma.v[panel])
  }
  
  # censoring indicator
  delta <- as.numeric(censtimes > ytilde)
  y <- ifelse(as.vector(delta) == 1, as.vector(ytilde), 
              as.vector(censtimes))
  
  #vector of dimension (nx1)
  list(y=y, ytilde=ytilde, cens=censtimes, delta=delta) 
}

### DATA SIMULATION in VECTOR form - LIST
simu_weibList <- function(X, panel, psi, lambda = NULL, 
                          varsigma = 1, Nsim = 1, seed = 123) {
  if (is.null(seed)) seed = .Random.seed
  set.seed(seed)
  
  n <- nrow(X)                #sum(T_i)
  N <- length(unique(panel))  #N
  T_i <- tapply(rep(1, n), panel, sum)
  
  # varsigma tunes the censoring times' distribution and the cluster-specific intercepts
  varsigma.v <- as.vector(varsigma)
  if ((length(varsigma.v) != 1)&(length(varsigma.v) != N)) 
    stop ("Wrong length of varsigma!")
  
  if (is.null(lambda)) lambda <- rnorm(N, mean = varsigma.v, 
                                       sd = sqrt(0.045))
  lambda.v <- as.vector(lambda)
  
  data.sim <- as.list(numeric(Nsim))
  
  for (i in 1:Nsim) {
    data <- simu_weib(X = X, panel = panel, psi = psi, 
                      lambda = lambda, varsigma = varsigma)
    data.sim[[i]] <- list(id = i, y = data$y, delta = data$delta)
  }
  attr(data.sim, "psi") <- psi
  attr(data.sim, "xi") <- xi
  attr(data.sim, "beta") <- beta
  attr(data.sim, "lambda") <- lambda
  attr(data.sim, "varsigma") <- varsigma.v
  attr(data.sim, "seed") <- seed
  attr(data.sim, "X") <- X
  attr(data.sim, "panel") <- panel
  attr(data.sim, "N") <- N
  attr(data.sim, "T") <- T_i
  data.sim
}

# data synthesis
syn2 <- function(y, xi, panel) tapply(y^xi, panel, sum)

### PROFILE LIK
# compute MLE for psi
# input y, delta, panel: vector n x 1
# input X: matrix n x (k0-1)
# input initial.val: vector k0 x 1

# compute lambdahat_psi, for fixed psi=(xi, beta),  (Nx1)
lambdahat_psi <- function(par, y, delta, X, panel) {
  xi <- par[1]
  beta <- par[-1]
  
  if(length(beta) != ncol(X)) stop ("Wrong length of parameter psi!")
  xb <- X %*% beta # vector n x 1
  
  di. <- syn2(delta, xi = 1, panel=panel) # vector Nx1
  s2 <- tapply(((y^xi)*exp(- xi*xb)), panel, sum) # vector Nx1
  est <- -(1/xi) * log(di./s2)           
  return(est)
}

# constr estimates of nuisance with C
lambdahat_psiC <- function(psi, y, delta, X, panel) {   
  xi <- psi[1]
  beta <- psi[-1]
  N <- length(unique(panel))   ##N.inf
  T_i <- tapply(rep(1, nrow(X)), panel, sum)   #T_i
  .C("lambda_psi",
    as.integer(sum(T_i)),
    as.integer(N),
    as.integer(T_i),
    as.integer(max(T_i)),
    as.double(xi),
    as.double(beta),
    as.integer(length(beta)),
    as.double(y),
    as.double(X),       #X nxlength(beta)
    as.integer(delta),
    lambda = as.double(rep(0.0, N)))$lambda
}

# compute l_(lambda_i, lambda_i)(theta), vector Nx1
l_ll <- function(par, lambda, y, delta, X, panel) {
  xi <- par[1]
  beta <- par[-1]
  xb <- X %*% beta # vector n x 1
  di. <- syn2(delta, xi = 1, panel = panel) # vector Nx1
  s2 <- tapply(((y^xi)*exp(-xi*xb)), panel, sum) # vector Nx1
  l <- - (xi^2) * exp(-lambda*xi) * s2        # vector Nx1   
  return(l)
}

# negative PL(psi) for random-censored data, psi=(xi, beta)
prof.lik <- function(par, y, delta, X, panel) {
  xi <- par[1]
  beta <- par[-1]
  
  if (length(beta) != ncol(X)) stop ("Wrong length of parameter psi!")
  xb <- X %*% beta # vector n x 1
  
  s1 <- sum(delta*xb) # scalar
  s2 <- tapply(((y^xi) * exp(- xi*xb)), panel, sum) # vector Nx1
  s3 <- sum(delta*log(y))  # scalar 
  
  di. <- syn2(delta, xi = 1, panel = panel) # vector Nx1
  d.. <- sum(di.) # scalar
  
  l <- d..*(log(xi) - 1) + (xi - 1)*s3 + sum(di.*log(di.)) - 
    sum(di.*log(s2)) - xi*s1
  return(-l)
}

# negative PL(omega) for random-censored data, omega=(log xi, beta)
PLomega <- function(omega, y, delta, X, panel) {
  psi <- psi.f(omega)
  prof.lik(psi, y, delta, X, panel)
}

# negative profile log-lik of scalar xi
prof.xi <- function(xi, y, delta, X, panel) {
  ncov <- ncol(X)
  beta.xi <- optim(rep(0, ncov), function(k) prof.lik(par = c(xi, k), 
                                      y = y, delta = delta, X = X,
    panel = panel), method="L-BFGS-B")$par
  prof.lik(c(xi, beta.xi), y, delta, X, panel)
}

# negative PL of scalar log(xi)
prof.xi <- function(lxi, y, delta, X, panel) {
  xi <- exp(lxi)
  prof.xi(xi, y, delta, X, panel)
}

# compute  l_(lambda_i)(theta) (Nx1)
l_lambda <- function(par, lambda, y, delta, X, panel) {
  xi <- par[1]
  beta <- par[-1]
  
  if(length(beta)!=ncol(X)) stop("Wrong length of parameter psi!")
  xb <- X %*% beta # vector n x 1
  
  di. <- syn2(delta, xi = 1, panel = panel) # vector Nx1
  s2 <- tapply(((y^xi)*exp(-xi*xb)), panel, sum) # vector Nx1
  l <- - (xi*di.) + xi*s2*exp(- lambda*xi)           
  return(l)
}

# MPL function of psi
MPLsurvC <- function(psi, y, delta, ystar, deltastar, 
                     X, panel, psihat, lambdahat) {
  xi <- psi[1]
  beta <- psi[-1]
  xihat <- psihat[1]
  betahat <- psihat[-1]
  N <- length(unique(panel))   ##N.inf
  T_i <- tapply(rep(1,nrow(X)), panel, sum)   #T_i
  R <- ncol(ystar)
  out<-.C("MPLsurvC",
    as.double(xi),
    as.double(beta),
    as.integer(length(beta)),
    as.double(X),       #X nxlength(beta)
    as.integer(N),
    as.integer(T_i),
    as.integer(sum(T_i)),
    as.integer(max(T_i)),
    as.double(y),
    as.integer(delta),
    as.double(ystar),      #matrix nxR
    as.integer(deltastar),
    as.integer(R),
    as.double(xihat),
    as.double(betahat),
    as.double(lambdahat),
    out = as.double(0.0))$out
  return(-out)
}

# MPL function of omega
MPLomega <- function(omega, y, delta, ystar, deltastar, 
                     X, panel, psihat, lambdahat) {
  psi <- psi.f(omega)
  MPLsurvC(psi, y, delta, ystar, deltastar, X, 
           panel, psihat, lambdahat)
}

#resample the censoring time (from the observed censored times) 
# for those subjects who
#had an observed failure (delta_ij=1) 
MC.condcens <- function(y, delta, Cobs, Sobs) {
  d.. <- sum(delta)
  time.int <- findInterval(y, c(0, Cobs-1e-8, Inf))
  surv <- c(1, Sobs)[time.int] #survival values at observed times
  surv[delta == 1] <- surv[delta == 1] * runif(d..)  
  #survival of new censoring times
  
  if(any(Sobs == 0)) {
    breaks <- c(sort(Sobs), 1)
    km_time <- Cobs
  } 
  else {
    breaks <- c(0, sort(Sobs), 1) 
    km_time <- c(Cobs, Inf)
  }	
  surv.int <- findInterval(surv, breaks)
  cstar <- rev(km_time)[surv.int] 
  cstar[delta==0] <- y[delta == 0]
  return(cstar) 
}	          	        

#generate right-censored samples, where failure times are from Weibull distr. with parameters
#thetahat, censoring times are generated from the empirical conditional distribution of the
#observed censoring times, given that C>T
MCrepl <- function(R, psi, lambda, y, delta, X, panel)  {
  
  xi <- psi[1]
  beta <- psi[-1]
  
  lambda.v <- as.vector(lambda)
  N <- length(lambda.v)
  
  xb <- X %*% beta
  eta <- exp(-(xb + lambda.v[panel])) #vector n x 1
  
  # Kaplan-meier survival estimate for censoring
  km <- survfit(Surv(y, delta==0) ~ 1, type = "kaplan-meier")
  Cobs <- km$time[km$n.event > 0]
  Sobs <- km$surv[km$n.event > 0]
  
  MC <- replicate(R, MCsample(xi, eta, y, delta, Cobs, Sobs)) 
  ## 2 matrices nxR
  return(MC)
}

MCsample <- function(xi, eta, y, delta, Cobs, Sobs) {
  # uncensored data from Weibull distr.
  ytildestar <- rweibull(length(eta), shape = xi, scale = 1/eta)  #nx1
  # generate cens times from conditional distr.
  cstar <- MC.condcens(y, delta, Cobs, Sobs) # nx1
  # Observe the minimum between the two times 
  ystar <- pmin(ytildestar, cstar)
  deltastar <- as.numeric(cstar > ytildestar)
  return(list(ystar = ystar, deltastar = deltastar) )
}

###################################################

#data as list - one dataset
survMPL.simuList1 <- function(data, R = 500, seedBoot = 123,
                              X, panel, trace = TRUE) {
  
  if (trace == TRUE) print(data$id)
  
  mleErr <- FALSE
  mleMPLerr <- FALSE
  SEerr <- FALSE
  SEmplErr <- FALSE
  
  delta1 <- data$delta
  y1 <- data$y
  
  n <- nrow(X)                        
  N <- length(unique(panel))                
  T <- tapply(rep(1, n), panel, sum)   
  ncov <- ncol(X)                           
  
  di. <- syn2(delta1, 1, panel) 
  Ncens <- length(delta1) - sum(delta1)  # total number of censored obs.
  
  ## remove noninformative strata with all censored obs.
  cond <- !(di. == 0)
  ind <- match(panel, names(cond))
  sele <- cond[ind]
  
  y.i <- y1[sele]
  X.i <- as.matrix(X[sele, ])
  delta.i <- delta1[sele]
  Ninf <- sum(cond)
  
  ## new panel indicator
  panel.i <- get.g(panel[sele])
  
  ## reparametrization -> no constraints on parameters
  ## MLE
  mle.out <- tryCatch(optim(rep(0, ncov + 1), PLomega, y = y.i, 
                          delta = delta.i, X = X.i, 
    panel = panel.i), error = function(e) print("error mle"))
  if (is.character(mle.out)) {
    xihat <- NA
    xihat.SE <- NA
    betahat <- rep(NA,ncov)
    betahat.SE <- rep(NA,ncov)
    xihatMPL <- NA
    xihatMPL.SE <- NA
    betahatMPL <- rep(NA,ncov)
    betahatMPL.SE <- rep(NA,ncov)
    mleErr <- TRUE
  }
  else {
    xihat <- exp(mle.out$par[1])
    betahat <- mle.out$par[-1]
    SE <- tryCatch(as.vector(diag(solve(numDeriv::hessian(prof.lik, 
                x = psi.f(mle.out$par), X = X.i, y = y.i, 
      delta = delta.i, panel = panel.i)))^.5), 
      error = function(e) print("error SE"))
    if (is.character(SE))  {
      xihat.SE <- NA
      betahat.SE <- rep(NA,ncov)
      SEerr <- TRUE
    }
    else {
      xihat.SE <- SE[1]
      betahat.SE <- SE[-1]
    }
    
    psihat <- psi.f(mle.out$par)
    lambdahat <- lambdahat_psiC(psihat, y = y.i, delta = delta.i, X = X.i, 
                              panel = panel.i)
    
    # generate R Monte Carlo simulated data
    if (is.null(seedBoot)) seedBoot = 123
    set.seed(seedBoot)
    MC <- MCrepl(R = R, psi = psihat, lambda = lambdahat, y = y.i, 
                 delta = delta.i, X = X.i, panel = panel.i)
    ystar.i <- matrix(unlist(MC["ystar", ]), nrow = n, ncol = R, 
                      byrow = F)
    deltastar.i <- matrix(unlist(MC["deltastar", ]), nrow = n, 
                          ncol = R, byrow = F)
    
    ## reparametrization: MPL in omega
    ## MCMPL
    MPL.out <- tryCatch(optim(mle.out$par, MPLomega, y = y.i, 
                              delta = delta.i, ystar = ystar.i,
      deltastar = deltastar.i, X = X.i, panel = panel.i, psihat = psihat,
      lambdahat = lambdahat), error = function(e) print("error MPL"))
    
    if(is.character(MPL.out)) {
      xihatMPL <- NA
      xihatMPL.SE <- NA
      betahatMPL <- rep(NA,ncov)
      betahatMPL.SE <- rep(NA,ncov)
      mleMPLerr <- TRUE
    }
    else {
      xihatMPL <- exp(MPL.out$par[1])
      betahatMPL <- MPL.out$par[-1]
      
      SEmpl <- tryCatch(as.vector(diag(solve(numDeriv::hessian(MPLsurvC, 
                        x = psi.f(MPL.out$par), y = y.i,
        delta = delta.i, ystar = ystar.i, deltastar = deltastar.i,
        X = X.i, panel = panel.i, psihat = psihat,
        lambdahat = lambdahat)))^.5),
        error=function(e) print("error SEmpl"))
      if(is.character(SEmpl)) {
        xihatMPL.SE <- NA
        betahatMPL.SE <- rep(NA,ncov)
        SEmplErr <- TRUE
      }
      else {
        xihatMPL.SE <- SEmpl[1]
        betahatMPL.SE <- SEmpl[-1]
      }
    }
  }
  data.frame(xihat = xihat, xihat.SE = xihat.SE, 
             xihatMPL = xihatMPL, xihatMPL.SE = xihatMPL.SE, 
    betahat1 = betahat[1], betahat1.SE = betahat.SE[1], 
    betahatMPL1 = betahatMPL[1], betahatMPL1.SE = betahatMPL.SE[1], 
    betahat2 = betahat[2], betahat2.SE = betahat.SE[2],
    betahatMPL2 = betahatMPL[2], betahatMPL2.SE = betahatMPL.SE[2], 
    N.inf = Ninf, tot.cens = Ncens, mleErr = mleErr, 
    mleMPLerr = mleMPLerr, SEmplErr = SEmplErr, SEerr = SEerr)
}

## stratified Cox PH model
simu_cox <- function(data) {
  X <- attr(data, "X")
  panel <- attr(data, "panel")
  xi <- attr(data, "xi")
  beta <- attr(data, "beta")
  
  Nsim <- length(data)
  q <- length(unique(panel))
  m <- tapply(rep(1, nrow(X)), panel, sum)   
  ncov <- ncol(X)                            
  
  # prepare output vectors
  betahat.cox <- matrix(NA, nrow = ncov, ncol = Nsim)
  exp_betahat.cox <- matrix(NA, nrow = ncov, ncol = Nsim)
  betahat.cox.SE <- matrix(NA, nrow = ncov, ncol = Nsim)
  err <- 0

  for (i in 1:Nsim) {
    # i-th dataset
    data.i <- data[[i]]
    y <- data.i$y
    delta <- data.i$delta
    
    if (i%%100 == 0) print(i) # monitor progress
    
    cox.out <- tryCatch(coxph(Surv(y, delta) ~ X + strata(panel)), 
                         error = function(e) print("error cox"))
    if (is.character(cox.out)) {
      betahat.cox[, i] <- rep(NA, ncov)
      exp_betahat.cox[, i] <- rep(NA, ncov)
      err <- err + 1
    }
    else {
      betahat.cox[, i] <- summary(cox.out)$coefficients[1:ncov, 1]
      exp_betahat.cox[, i] <- summary(cox.out)$coefficients[1:ncov, 2]
      betahat.cox.SE[, i] <- summary(cox.out)$coefficients[1:ncov, 3]
    }
  }
  
  list(betahat.cox = betahat.cox, betahat.cox.SE = betahat.cox.SE,
       beta = beta, err = err, q = q, m = m, seed = attr(data, "seed"), 
       data = data, xi = xi, rr = exp(-xi * beta), exp_betahat.cox = exp_betahat.cox)
}

survMPL.simuListAll <- function(data_all, R = 500, 
                              seedBoot = 123, cores = 1, 
                              trace = TRUE) {
  require(plyr)
  require(doMC)
  registerDoMC(cores)
  
  X <- attr(data_all, "X")
  panel <- attr(data_all, "panel")
  xi <- attr(data_all, "xi")
  beta1 <- attr(data_all, "beta")[1]
  beta2 <- attr(data_all, "beta")[2]
  
  Nsim <- length(data_all)
  N <- length(unique(panel))                
  T <- tapply(rep(1,nrow(X)), panel, sum)   
  ncov <- ncol(X)                           
  
  out <- ldply(.data = data_all, .fun = survMPL.simuList1, 
               R = R, seedBoot = 123, X = X, 
                panel = panel, trace = trace, .parallel = TRUE)
  data.frame(out, xi = xi, beta1 = beta1, beta2 = beta2)
}

### simulate datasets with T=4, N=50 and proportion of censored observations prob.cens
N <- 50
T <- 4
ncov <- 2
panelInd <- rep(1:N, each = T)

set.seed(321)
p <- 0.5
X <- matrix(NA, nrow = N*T, ncol = ncov)
X[, 1] <- rep(c(rep(0, floor(T/2)), rep(1, ceiling(T/2))), N)
X[, 2] <- rnorm(N*T, 0, 1)

xi <- 1.5
beta <- c(-1, 1)
psi <- c(xi, beta)


### mean(log(eta))=0, var(log(eta))=1.5
mustar <- - 0 - beta[1]*p   # 0.5
sigmastar <- sqrt(1.5 - (beta[1]^2)*p*(1 - p) - beta[2]^2)    # 0.5

lambda <- rnorm(N, mustar, sd = sigmastar)

prob.cens <- 0.2      # prob. of censoring in whole dataset
#prob.cens <- 0.4      # prob. of censoring in whole dataset

# find parameter of censoring times' distibution 
varsigma <- varsigma.cens(psi = psi, lambda = lambda, X = X, 
                          panel = panelInd, prob.cens)$varsigma

nsimu <- 2000

y450surv02 <- simu_weibList(X = X, panel = panelInd, psi = psi, 
                            lambda = lambda, varsigma = varsigma,
                            Nsim = nsimu, seed = 123)

res450surv02 <- survMPL.simuListAll(y450surv02, R = 500, 
                                    seedBoot = 123, cores = 1, 
                                    trace = TRUE)

res450cox02 <- simu_cox(y450surv02)

